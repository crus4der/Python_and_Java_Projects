import pygame, os, json
from CPE8.TypeZone.functions import *
from CPE8.TypeZone.icons import homepage_icon, icon_select
from CPE8.TypeZone.challenges import challenge
from CPE8.TypeZone.main_lesson import main_page
from CPE8.TypeZone.test import multiplay
from CPE8.TypeZone.touch_type import touch_type
from CPE8.TypeZone.prof import profile_blit, settings
pygame.init()
screen = pygame.display.set_mode((1280, 720))
homepage_image = pygame.image.load('TypeZone/Images/homapage_01.png')
homepage_bg = pygame.transform.scale(homepage_image, (1280, 720))


hp_icon1 = pygame.image.load('TypeZone/Images/keyboard.png')
hp_icon2 = pygame.image.load('TypeZone/Images/43212.png')
hp_icon2 = pygame.transform.scale(hp_icon2,(130, 130))
hp_icon3 = pygame.image.load('TypeZone/Images/settings.png')
hp_icon3 = pygame.transform.scale(hp_icon3,(118, 91))
hp_icon4 = pygame.transform.scale(pygame.image.load('TypeZone/Images/achievements_w.png'),(95, 95))
hp_icon4.set_alpha(80)
hp_icon3.set_alpha(100)
hp_icon2.set_alpha(255)
hp_icon1.set_alpha(255)


clock = pygame.time.Clock()
click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')




# rectangle

def homepage(user, user_icon):

    color = pygame.Color('white')
    inactive_color = pygame.Color('#243240')
    active_color = pygame.Color('#FFFF33')

    # buttons
    profile = Button((255, 255, 255), 50, 40, 64, 64)   # profile button
    home = Button((255, 255, 255), 1200, 40, 64, 64)    # home button
    lesson = Button(color, 785, 420, (385/2)-5, 220)    # lesson button
    challenges = Button(color, 785, 75, 385, 335)       # challenges
    multiplayer = Button(color, 982.5, 420, (385/2) - 5, (220 / 2) - 5)
    setting = Button(color, 982.5, 535, (385/2) - 5, (220 / 2) - 5)


    with open('save.json', 'r') as sounds:
        sound = json.load(sounds)
    pygame.mixer.music.set_volume(sound['vol'])
    loop = True
    while loop:

        pygame.mixer.music.unpause()
        screen.blit(homepage_bg, (0, 0)) # Display background

        # draw profile
        draw_text(20, None, None, 135, 60, inactive_color, user, screen, True)
        draw_text(13, None, None, 135, 80, inactive_color, 'BEGINNER', screen)
        homepage_icon(user_icon, (50, 40))

        # draw rect
        draw_rect(385, 335, pygame.Color('#3A5B63'), 242, 10, 785, 75, screen)                        # Take Challenge
        draw_rect((385 / 2) - 5, 220, pygame.Color('#4A7C29'), 242, 10, 785, 420,screen)             # Lesson Module
        draw_rect((385 / 2) - 5, (220 / 2) - 5, pygame.Color('#B53513'), 242, 10, 982.5, 420,screen) # Multiplayer
        draw_rect((385 / 2) - 5, (220 / 2) - 5, inactive_color, 242, 10, 982.5, 535,screen) # Settings

        # homapage icon
        screen.blit(hp_icon1, (835, 265))
        screen.blit(hp_icon2, (815, 500))
        screen.blit(hp_icon3, (1045.5, 540))
        screen.blit(hp_icon4, (1070, 425))

        # draw text
        draw_text(53, 'TAKE', 'CHALLENGE', 815, 147, color, None, screen)       # text: TAKE CHALLENGE
        draw_text(28, 'LESSON', 'MODULE', 815, 450, color, None,screen)        # text: LESSON MODULE
        draw_text(18, 'MULTIPLAYER', None, 1008.5, 445, color, None, screen)    # text: MULTIPLAYER
        draw_text(18, 'SETTINGS', None, 1008.5, 560, color, None, screen)       # text: SETTINGS

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:

                if profile.isOver(pos):
                    click.play()
                    loop = False
                    profile_blit(user, user_icon)
                    with open('save.json', 'r') as users:
                        data_obj = json.load(users)
                    homepage(data_obj['user'], icon_select(data_obj['user_icon']))

                elif lesson.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    a_file = open("save.json", "r")
                    les_obj = json.load(a_file)
                    a_file.close()

                    if les_obj['tt'] == 0:
                        touch_type()
                        les_obj['tt'] = 1
                        file = open('save.json', 'w')
                        json.dump(les_obj, file, indent=4)
                        file.close()


                    main_page()

                elif challenges.isOver(pos):
                    # enter challenge module
                    click.play()
                    challenge()

                elif multiplayer.isOver(pos):
                    # enter multiplayer module
                    click.play()
                    multiplay()


                elif setting.isOver(pos):
                    # eneter multiplayer module
                    click.play()
                    loop = False
                    settings(user,user_icon)
                    with open('save.json', 'r') as users:
                        data_obj = json.load(users)
                    homepage(data_obj['user'], icon_select(data_obj['user_icon']))






        pygame.display.flip()
        clock.tick(60)

