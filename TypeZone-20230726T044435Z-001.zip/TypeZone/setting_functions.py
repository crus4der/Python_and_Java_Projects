import pygame, sys
from CPE8.TypeZone.functions import draw_rect, Button

screen = pygame.display.set_mode((1280, 720))
pygame.init()
font_v = pygame.font.SysFont('Calibri', 60, True)
font_z = pygame.font.SysFont('Calibri', 27)
x_icon = pygame.image.load('TypeZone/Images/remove.png')
click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')

remove = Button((255,255,255), 1210,  35, 24, 24)

def text(txt,x,y):
    betat = font_z.render(txt, True, pygame.Color('#3C3C35'))
    screen.blit(betat, (x, y)) #185 200

def beta_pop():

    a = "It is in the second development phase and hasn't reached alpha testing. The Alpha"
    b = "version describes a development status that usually means the first complete"
    c = "version of a  program or application, which is most likely unstable,"
    d = "but is useful to show what the product will do, usually,"
    e = "a selected group—and is also called the preview"
    f = 'version; the beta version is usually the '
    g = "last version before wide release."

    draw_rect(1280, 720, (0, 0, 0), 150, 0, 0, 0, screen)
    pygame.display.update()
    loop = True
    while loop:

        beta_test = font_v.render('BETA TEST', True, pygame.Color('#B53513'))

        screen.blit(x_icon, (1210, 35))
        beta = pygame.image.load('TypeZone/Images/beta_test.png')
        draw_rect(1080, 608, (255,255,255), 255, 20, 100, 56, screen)
        screen.blit(beta, (690, 340))
        screen.blit(beta_test, (180, 120))
        text(a, 185, 210)
        text(b, 185, 260)
        text(c, 185, 310)
        text(d, 185, 360)
        text(e, 185, 410)
        text(f, 185, 460)
        text(g, 185, 510)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if remove.isOver(pos):
                    click.play()
                    loop = False

def typezone_pop():
    a = "ADAM Corp. is a concept tied in with the initials of the company owners. Also, ADAM"
    b = "is from Hebrew origin means 'Earth'. This implies that we, in ADAMCorp., if there's"
    c = "a given opportunity to us to expand our company more, we will give the best"
    d = "product and services in order to satisfy our customers around the world."

    draw_rect(1280, 720, (0, 0, 0), 150, 0, 0, 0, screen)
    pygame.display.update()

    loop =  True
    while loop :


        adam_corp = pygame.transform.scale(pygame.image.load('TypeZone/Images/Adam.png'), (150, 92))
        type_zone = pygame.transform.scale(pygame.image.load('TypeZone/Images/TypeZone.png'), (150, 100))
        beta_test = font_v.render('ABOUT US', True, pygame.Color('#4A7C29'))
        beta = pygame.image.load('TypeZone/Images/company.png')


        draw_rect(1080, 608, (255, 255, 255), 255, 20, 100, 56, screen)
        screen.blit(beta_test, (180, 120))
        screen.blit(x_icon, (1210, 35))
        screen.blit(beta, (690, 340))
        text(a, 185, 220)
        text(b, 185, 270)
        text(c, 185, 320)
        text(d, 185, 370)
        screen.blit(adam_corp, (280, 500))
        screen.blit(type_zone, (480, 498))
        pygame.display.update()
        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if remove.isOver(pos):
                    click.play()
                    loop = False

def feedback_pop():

    draw_rect(1280, 720, (0, 0, 0), 150, 0, 0, 0, screen)
    pygame.display.update()

    loop = True
    while loop:

        beta = pygame.image.load('TypeZone/Images/feedback.png')
        gmail = pygame.image.load('TypeZone/Images/gmail (1).png')
        beta_test = font_v.render('SEND US A MESSAGE', True, pygame.Color('#3A5B63'))

        draw_rect(1080, 608, (255, 255, 255), 255, 20, 100, 56, screen)
        screen.blit(x_icon, (1210, 35))
        screen.blit(beta_test, (180, 120))
        screen.blit(beta, (690, 180))
        screen.blit(gmail, (200, 220))
        text('adamcorporation8@gmail.com', 250, 223)
        pygame.display.update()
        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if remove.isOver(pos):
                    click.play()
                    loop = False

def power():
    y = Button((255,255,255), 570, 370, 60, 30)
    n = Button((255,255,255), 640, 370, 60, 30)
    draw_rect(1280, 720, (0, 0, 0), 150, 0, 0, 0, screen)
    pygame.display.update()

    loop = True
    while loop:

        draw_rect(250, 150, (255,255,255), 255, 10, 1280/2 - 250/2, 720/2 - 150/2, screen)
        draw_rect(60, 30 , pygame.Color('#4A7C29'),255, 2, 570, 370, screen)
        draw_rect(60, 30, pygame.Color('#B53513'), 255, 2, 640, 370, screen)
        font_x = pygame.font.SysFont('Calibri', 20, True)
        font_xz = pygame.font.SysFont('Calibri', 18, True)
        txt = font_x.render('Do you want to quit?', True, pygame.Color('black'))
        ytxt = font_xz.render('YES', True, pygame.Color('black'))
        ntxt = font_xz.render('NO', True, pygame.Color('black'))
        screen.blit(ytxt, (y.x + (y.width/2 - ytxt.get_width()/2), y.y + (y.height/2 - ytxt.get_height()/2)))
        screen.blit(ntxt, (n.x + (n.width / 2 - ntxt.get_width() / 2), n.y + (n.height / 2 - ntxt.get_height() / 2)))
        screen.blit(txt, (1280/2 - 250/2 + 20, 720/2 - 150/2 + 30))
        pygame.display.update()
        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if y.isOver(pos):
                    pygame.quit()
                    sys.exit()
                elif n.isOver(pos):
                    loop = False


