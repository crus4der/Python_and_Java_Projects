
import pygame

win = pygame.display.set_mode((1280, 720))
win.fill((255, 255, 255))


# Icon Size
Icon_width, Icon_height = 100, 100
# Icons
# def icon_image(name):
Main_user_Image = pygame.image.load('TypeZone/Icons/user.png')
User1_Image = pygame.image.load('TypeZone/Icons/abra.png')
User2_Image = pygame.image.load('TypeZone/Icons/bellsprout.png')
User3_Image = pygame.image.load('TypeZone/Icons/bullbasaur.png')
User4_Image = pygame.image.load('TypeZone/Icons/caterpie.png')
User5_Image = pygame.image.load('TypeZone/Icons/mankey.png')
User6_Image = pygame.image.load('TypeZone/Icons/meowth.png')
User7_Image = pygame.image.load('TypeZone/Icons/mew.png')
User8_Image = pygame.image.load('TypeZone/Icons/pidgey.png')
User9_Image = pygame.image.load('TypeZone/Icons/psyduck.png')
User10_Image = pygame.image.load('TypeZone/Icons/rattata.png')
User11_Image = pygame.image.load('TypeZone/Icons/squirtle.png')
User12_Image = pygame.image.load('TypeZone/Icons/venonat.png')


Main_user = pygame.transform.scale(Main_user_Image, (Icon_width, Icon_height))
User1 = pygame.transform.scale(User1_Image, (Icon_width, Icon_height))
User2 = pygame.transform.scale(User2_Image, (Icon_width, Icon_height))
User3 = pygame.transform.scale(User3_Image, (Icon_width, Icon_height))
User4 = pygame.transform.scale(User4_Image, (Icon_width, Icon_height))
User5 = pygame.transform.scale(User5_Image, (Icon_width, Icon_height))
User6 = pygame.transform.scale(User6_Image, (Icon_width, Icon_height))
User7 = pygame.transform.scale(User7_Image, (Icon_width, Icon_height))
User8 = pygame.transform.scale(User8_Image, (Icon_width, Icon_height))
User9 = pygame.transform.scale(User9_Image, (Icon_width, Icon_height))
User10 = pygame.transform.scale(User10_Image, (Icon_width, Icon_height))
User11 = pygame.transform.scale(User11_Image, (Icon_width, Icon_height))
User12 = pygame.transform.scale(User12_Image, (Icon_width, Icon_height))

def icon(name, def_pos):
    win.blit(name, def_pos)
    return name, def_pos

def homepage_icon(name, pos):
    user_icon = pygame.transform.scale(name, (64, 64))
    win.blit(user_icon, pos)

def run_icon():
    win.fill((255,255,255))
    icon(Main_user, (585, 100))
    icon(User1, (210, 400))
    icon(User2, (360, 400))
    icon(User3, (510, 400))
    icon(User4, (660, 400))
    icon(User5, (810, 400))
    icon(User6, (960, 400))
    icon(User7, (210, 550))
    icon(User8, (360, 550))
    icon(User9, (510, 550))
    icon(User10, (660, 550))
    icon(User11, (810, 550))
    icon(User12, (960, 550))



def icon_change():
    show = bool
    win.fill((255,255,255))
    icon(User1, (210, 400))
    icon(User2, (360, 400))
    icon(User3, (510, 400))
    icon(User4, (660, 400))
    icon(User5, (810, 400))
    icon(User6, (960, 400))
    icon(User7, (210, 550))
    icon(User8, (360, 550))
    icon(User9, (510, 550))
    icon(User10, (660, 550))
    icon(User11, (810, 550))
    icon(User12, (960, 550))

def icon_select(x):

    if x == 1:
        return User1
    elif x == 2:
        return User2
    elif x == 3:
        return User3
    elif x == 4:
        return User4
    elif x == 5:
        return User5
    elif x == 6:
        return User6
    elif x == 7:
        return User7
    elif x == 8:
        return User8
    elif x == 9:
        return User9
    elif x == 10:
        return User10
    elif x == 11:
        return User11
    elif x == 12:
        return User12


