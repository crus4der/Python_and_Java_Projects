import pygame, os, sys
from CPE8.TypeZone.functions import rect, Button, draw_rect, draw_text
pygame.init()


SIZE = WIDTH, HEIGHT = (1280, 720)
FPS = 30
screen = pygame.display.set_mode(SIZE)
clock = pygame.time.Clock()
pretest = 'The quick brown fox jumps over the lazy dog.'
get = ''

#xt = "This is a really long sentence with a couple of breaks. Sometimes it will break even if there isn't a break " \
#      #"in the sentence, but that's because the text is too long to fit the screen. It can look strange sometimes." \
#      #"This function doesn't check if the text is too high to fit on the height of the surface though, so sometimes " \
#      #"text will disappear underneath the surface."



def blit_text(surface, text, pos, font, color):
    words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
    space = font.size(' ')[0]  # The width of a space.
    max_width, max_height = surface.get_size()
    x, y = pos
    max_width = max_width - 150

    wid, hei = 0, 0
    for line in words:
        for word in line:
            word_surface = font.render(word, True, color)
            word_width, word_height = word_surface.get_size()
            #hei = word_height
            if x + word_width >= max_width:

                x = pos[0]  # Reset the x.
                y += word_height + 17  # Start on new row.
            for let in word:
                let_surface = font.render(let, True, pygame.Color('#4a4a4a'))
                let_width, let_height = let_surface.get_size()
                wid = let_width

                surface.blit(let_surface, (x, y))
                x += let_width + space
            x += wid



        #x = pos[0]  # Reset the x.
        #y += hei  # Start on new row.



def testing(txt, font, px, py):
    click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')
    color = pygame.Color('white')
    def_color = pygame.Color('#4a4a4a')
    correct_color = pygame.Color('green')
    wrong_color = pygame.Color('red')
    start = Button(def_color, 950, 600, 235, 62)
    strt = Button.draw_rect(start, 0, screen, 35)
    typingzone = pygame.image.load('TypeZone/Images/typing.png')
    type_sound = pygame.mixer.Sound('TypeZone/sounds/Type.mp3')


    error = 1
    i = 0
    x = 0
    total_width = 0
    add_height = 0
    testing.show = ''
    typing = False
    go = False


    done = False
    while not done:

        home_icon = pygame.image.load('TypeZone/Images/home.png')
        home_icon = pygame.transform.scale(home_icon, (32, 32))
        home = Button((255, 255, 255), 1180, 40, 40, 40)
        screen.fill((255, 255, 255))
        screen.blit(typingzone, (0,0))
        draw_rect(235,62, pygame.Color('#243240'), 255, 12, 950, 600, screen)
        draw_text(30, 'CONTINUE', None, 985, 618, color, None, screen)
        pygame.display.flip()
        testing.time = 0
        wid = 0
        active = False
        start_time = None

        for event in pygame.event.get():
            mpos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start.isOver(mpos):
                    screen.fill((255, 255, 255))
                    blit_text(screen, txt, (px, py), font, pygame.Color('#4a4a4a'))
                    start_time = pygame.time.get_ticks()
                    if pretest != txt:
                        screen.blit(home_icon, (1180, 40))
                    active = True
                    typing = True
            elif event.type == pygame.MOUSEMOTION:
                if start.isOver(mpos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

        while typing:

            draw_rect(100, 30, pygame.Color('white'), 255, 0, 35, 35, screen)
            pos = px, py
            p_x, p_y = pos
            space = font.size(' ')[0]
            post = (p_x, p_y)
            max_width = screen.get_width()
            max_width = max_width - 150
            sp = txt.split(' ')

            time_font = pygame.font.SysFont('Calibri', 18, True)
            surfs = time_font.render('Time: ' + str(round((pygame.time.get_ticks() - start_time) * .001)), True,
                                     pygame.Color('#243240'))
            screen.blit(surfs, (35, 35))

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()


                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if home.isOver(pygame.mouse.get_pos()):
                        click.play()
                        if pretest != txt:
                            screen.fill((255, 255, 255))
                            pygame.mixer.music.unpause()
                            typing = False




                elif event.type == pygame.KEYDOWN:
                    type_sound.play()
                    if event.key == pygame.K_SPACE:
                        if txt[x] == ' ':
                            reduce_surf = font.render(txt[x - 1], True, correct_color)
                            get_width = reduce_surf.get_width()
                            text_surf = font.render(txt[x], True, correct_color)
                            width, height = text_surf.get_size()
                            if x == 0:
                                screen.blit(text_surf, post)
                            else:
                                #blit_char(screen,p_x + total_width, p_y + add_height, text_surf)
                                rect(screen, (p_x  - get_width/2.3 + total_width, p_y + add_height), correct_color, width, height - 5, 65)
                                rect(screen, (p_x - get_width/2.3 + total_width, p_y + height + add_height), correct_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                            error = 1
                            total_width += get_width



                        else:
                            if error <= 2:

                                text_surf = font.render(txt[x], True, wrong_color)
                                width, height = text_surf.get_size()
                                rect(screen, (p_x + total_width - 2, p_y + add_height), wrong_color, width + 4, height - 3, 65)
                                rect(screen, (p_x + total_width, p_y + height + add_height), wrong_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                                x += 1
                                error += 2
                                testing.show += event.unicode
                                total_width += width + space





                        if error < 2 and x + 1 <= len(txt):
                            x += 1
                            testing.show += event.unicode
                        else:
                            x = x

                    elif event.unicode:
                        if event.unicode == txt[x]:
                            text_surf = font.render(txt[x], True, correct_color)
                            width, height = text_surf.get_size()
                            rect(screen, (p_x + total_width - 2, p_y + add_height), correct_color, width + 4, height - 3, 65)
                            rect(screen, (p_x + total_width, p_y + height + add_height), correct_color, width, 2, 100)
                            screen.blit(text_surf, (p_x + total_width, p_y + add_height))

                            total_width += space + width

                            error = 1



                        elif txt[x] != ' ':
                            if error <= 2:

                                text_surf = font.render(txt[x], True, wrong_color)
                                width, height = text_surf.get_size()

                                rect(screen, (p_x + total_width - 2, p_y + add_height), wrong_color, width + 4, height - 3,
                                     65)
                                rect(screen, (p_x + total_width, p_y + height + add_height), wrong_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                                error += 2
                                x += 1
                                testing.show += event.unicode
                                total_width += space + width


                        else:
                            if error <= 2:

                                reduce_surf = font.render(txt[x - 1], True, wrong_color)
                                get_width, get_height = reduce_surf.get_size()
                                surf = font.render(txt[x], True, wrong_color)
                                width, height = reduce_surf.get_size()
                                rect(screen, (p_x + total_width - get_width/2.3 , p_y + add_height), wrong_color, get_width, get_height - 3, 65)
                                rect(screen, (p_x + total_width - get_width/2.3 , p_y + height + add_height), wrong_color, get_width, 2, 100)
                                error += 1
                                x += 1
                                total_width += get_width
                                testing.show += event.unicode


                        if error < 2 and  x + 1 <= len(txt):
                            x += 1
                            testing.show += event.unicode
                        else:
                            x = x



                    if x  >= len(txt):
                        screen.fill((255, 255, 255))
                        typing = False




                    if txt[x - 1] == ' ':
                        if x >= len(txt):
                            x =  x - 1
                        if i + 2 <= len(sp):
                            word_surf = font.render(sp[i + 1], True, def_color)
                            word_width, word_height = word_surf.get_size()
                            wid = word_width
                        else:
                            i = i
                        if error <= 2:
                            if event.unicode:
                                i += 1
                                error += 1

                        wordsurf = font.render(sp[i], True, def_color)
                        wordwidth, wordheight = wordsurf.get_size()
                        if total_width + p_x + wid >= max_width and total_width + p_x + wordwidth >= max_width:
                                char_surf = font.render(txt[x], True, def_color)
                                char_width, char_height = char_surf.get_size()
                                total_width = 0
                                add_height += char_height + 17


            if active:
                if start_time:
                    time_since_enter = (pygame.time.get_ticks() - start_time) * .001
                    testing.time = round(time_since_enter)


            done = True
            pygame.display.flip()
            clock.tick(60)



