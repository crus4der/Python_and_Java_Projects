
import pygame, sys
from CPE8.TypeZone.lesson.images import *
from CPE8.TypeZone.functions import Button
from CPE8.TypeZone.lesson.rect import draw_rect, draw_text

class TouchType(object):

    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)

    def firstpage(self):
        blue_gray = (51, 63, 80)
        self.screen.blit(inf, (820, 120))
        self.screen.blit(kb, (250, 450))


        self.screen.blit(self.mainFont.render('Introduction to Typing Trainer', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('In this module, you will learn how to touch type', True, blue_gray), (200, 150))
        self.screen.blit(self.font.render('without needing to look at your keyboard and using', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('all ten fingers.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('By completing the following 5 lessons, you will', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('quickly develop fluent and error free touch typing', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('skills.', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('With regular practice, you can double or even triple', True, blue_gray), (200, 350))
        self.screen.blit(self.font.render('you\'re typing speed.', True, blue_gray), (200, 375))




    def addText(self):
        blue_gray = (51, 63, 80)


        self.screen.blit(inf, (820, 120))
        self.screen.blit(kb, (250, 450))

        self.screen.blit(self.mainFont.render('What is Touch Typing?', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Touch typing is a keyboarding technique used to', True, blue_gray),
                         (200, 200))
        self.screen.blit(self.font.render('help you type more accurately and efficiently', True, blue_gray),
                         (200, 225))
        self.screen.blit(self.font.render('without looking at the keyboard.', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('Here\'s how...', True, blue_gray), (200, 300))


    def addText2(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(kbh, (250, 450))

        self.screen.blit(self.mainFont.render('It Begins With The Home Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Stop bouncing around the keyboard and find the best', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('position of your fingers.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('The Home Keys, also called \"the home row\", are the ', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('keys A S D F and J K L ;. They\'re the starting point for', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('touch typing and the home base for each finger.', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Here they are on the keyboard:', True, blue_gray), (200, 350))


    def addText3(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(lefth, (250, 450))

        self.screen.blit(self.mainFont.render('Position Your Left Hand...', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Place your left hand on the keyboard.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Starting with you little finger on the A, place', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('remaining left hand fingers on the S D and F keys.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Let your thumb rest on the space bar.', True, blue_gray), (200, 325))

    def addText4(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(kbh, (250, 450))

        self.screen.blit(self.mainFont.render('Now For Your Right Hand', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Place your right hand on the keyboard.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Starting with you index finger, place', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('your fingers on the J K L and ; keys.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Again, rest your thumb on the space bar.', True, blue_gray), (200, 325))


    def addText5(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(kbh, (250, 450))

        self.screen.blit(self.mainFont.render('Your Fingers Are Now On The Home Row!', True, blue_gray), (250, 50))
        self.screen.blit(self.font.render('From now on, the Home Row will be the basic position for', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('your hands when you type.', True, blue_gray), (200, 225))
        self.screen.blit(self.font.render('TIP! When typing, keep your wrists up and your fingers', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('slightly curled and relaxed - you\'ll feel more comfortable.', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Next up, the secondary keys...', True, blue_gray),(200, 350))

    def addText6(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(full, (250, 450))

        self.screen.blit(self.mainFont.render('Reaching The Other Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('With your fingers in the Home Row, use the fingers', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('closest to each key to reach the other keys.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Look at the color coding in the picture below to see', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('which finger to use.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Green keys are pressed with the index finger, Blue with', True, blue_gray),(200, 325))
        self.screen.blit(self.font.render('the middle finger, purple with ring finger and dark green', True, blue_gray), (200, 350))
        self.screen.blit(self.font.render('ones with the pinky finger.', True, blue_gray), (200, 375))

    def addText7(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(full, (250, 450))

        self.screen.blit(self.mainFont.render('Try Pressing the Other Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Look at the keyboard picture below and press each', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('letter key on the top and bottom rows.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Try not to look at the keyboard and simply let your', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('fingers find the way.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Use a quick and light touch when pressing the keys.', True, blue_gray), (200, 325))

    def addText8(self):
        blue_gray = (51, 63, 80)

        self.screen.blit(inf, (820, 120))
        self.screen.blit(full, (250, 450))

        self.screen.blit(self.mainFont.render('The Lesson Module', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('How did that feel? Your next stop is the Lesson Module', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('where you\'ll get to learn, practice and try touch typing', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('more.', True, blue_gray), (200, 225))
        self.screen.blit(self.font.render('Try to use all fingers from their home row position, but', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('don\'t stress about speed and accuracy', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Are you ready?', True, blue_gray), (200, 350))

pygame.init()
screen = pygame.display.set_mode((1280, 720))


#z = [x.firstpage(), x.addText(), x.addText2(), x.addText3(), x.addText4(), x.addText5(), x.addText6(),
#     x.addText7(), x.addText8()]
def touch_type():
    font_v = pygame.font.Font('TypeZone/lesson/Valorant Font.ttf', 13)
    font_z = pygame.font.Font('TypeZone/lesson/Valorant Font.ttf', 30)
    cont = Button((255,255,255), 970, 600, 230, 62)
    bck = Button((255,255,255),30, 30, 65, 40)
    color = pygame.Color('white')
    i = 0
    lp = True
    while lp:


        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if cont.isOver(pos):
                    i += 1
                elif bck.isOver(pos) and i != 0:
                    i = i - 1

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')


        if i == 0:
            TouchType().firstpage()
        elif i == 1:
            TouchType().addText()
        elif i == 2:
            TouchType().addText2()
        elif i == 3:
            TouchType().addText3()
        elif i == 4:
            TouchType().addText4()
        elif i == 5:
            TouchType().addText5()
        elif i == 6:
            TouchType().addText6()
        elif i == 7:
            TouchType().addText7()
        elif i == 8:
            TouchType().addText8()
        else:
            screen.fill((255, 255, 255))
            break


        if i != 0:
            draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
            draw_text(font_v, 'BACK', None, 45, 45, (255, 255, 255), screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()
        pygame.time.Clock().tick(60)

