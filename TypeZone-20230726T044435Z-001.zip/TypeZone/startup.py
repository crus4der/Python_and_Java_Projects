from CPE8.TypeZone.functions import Button, close
from pygame import mixer
import os, random, sys, pygame


# Initialize pygame
pygame.init()

# window homepage
screen_size = (1280, 720)
screen = pygame.display.set_mode(screen_size)

# Title
icon = pygame.image.load('TypeZone/Icon.png')
pygame.display.set_caption("TypeZone")
pygame.display.set_icon(icon)


# Window Fill
# Screen  BG Color
def screen_draw():
    screen.fill((255, 255, 255))
    close()


# Background logo
def fade(width, height, load, show):

    # fade variables
    count = 1
    bg = pygame.image.load('TypeZone/Images/TypeZone.png')

    #fade in
    for alpha in range(0, 255, load):
        bg.set_alpha(alpha)
        screen_draw()
        screen.blit(bg, (640 - 128, 360 - 88))
        pygame.display.update()
        pygame.display.flip()
        pygame.time.delay(2)
        count += 1
        close()
    # Showtime
    pygame.time.delay(show)

    # fade out
    fading = True
    while fading:
        bg.set_alpha(count)
        screen_draw()
        screen.blit(bg, (640 - 128, 360 - 88))
        pygame.display.flip()
        pygame.display.update()
        pygame.time.delay(2)
        count = count - 1

        if count <= 0:
            fading = False
        close()

def fade_adam(width, height):

    # fade variables
    count = 1
    bg = pygame.image.load('TypeZone/Images/Adam.png')

    #fade in
    for alpha in range(0, 255, 2):
        bg.set_alpha(alpha)
        screen_draw()
        screen.blit(bg, (640 - 163, 360 - 97))
        pygame.display.update()
        pygame.display.flip()
        pygame.time.delay(2)
        count += 1

    # Showtime
    pygame.time.delay(3000)

    # fade out
    fading = True
    while fading:
        bg.set_alpha(count)
        screen_draw()
        screen.blit(bg, (640 - 163, 360 - 97))
        pygame.display.flip()
        pygame.time.delay(2)
        count = count - 1

        if count <= 0:
            fading = False
    close()



def start():

    bg_start = pygame.image.load('TypeZone/Images/startbg.png')
    resize =  pygame.transform.scale(bg_start, (1280, 720))
    colors = ['#BE1E2D', '#F15A29', '#1B75BC', '#594A42', '#ff33cc']

    #pygame.time.delay(1000)
    start_button = Button((255, 255, 255), 210, 475, 240, 70)
    #profile = button
    #statistics

    mixer.music.load('TypeZone/sounds/AdhesiveWombat - 8 Bit Adventure.mp3')
    mixer.music.set_volume(.3)
    mixer.music.play(-1, 0.0)
    color = (255, 255, 255)
    running = True
    while running:

        font = pygame.font.SysFont('Calibri', 45, True)
        pygame.time.delay(350)
        screen.fill(pygame.Color(random.choice(colors)))

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEMOTION:
                if start_button.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

            elif event.type == pygame.MOUSEBUTTONDOWN:
                    if start_button.isOver(pos):
                        click = mixer.Sound('TypeZone/sounds/Mouseclick.mp3')
                        click.play()
                        running = False


        screen.blit(resize, (0, 0))
        box = pygame.draw.rect(screen, color, pygame.Rect(210, 475, 240, 70), 2, 12)
        txt_surface = font.render("START", True, color)
        screen.blit(txt_surface, (box.x + (box.width / 2 - txt_surface.get_width() / 2),
                                  box.y + (box.height / 2 - txt_surface.get_height() / 2)))
        pygame.display.update()
        pygame.time.Clock().tick(60)
