import json, sys
from CPE8.TypeZone.icons import *
from CPE8.TypeZone.functions import draw_rect, Button, Player
screen = pygame.display.set_mode((1280, 720))
pygame.init()


white = pygame.Color('white')

def runicon():
    a_file = open("save.json", "r")
    data_obj = json.load(a_file)
    a_file.close()

    draw_rect(1080, 608, pygame.Color('white'), 255, 25, 100, 56, screen)
    draw_rect(1, 580, pygame.Color('black'), 255, 0, 680, 70, screen)

    screen.blit(User1, (170, 80))
    screen.blit(User2, (320, 80))
    screen.blit(User3, (480, 80))
    screen.blit(User4, (170, 230))
    screen.blit(User5, (320, 230))
    screen.blit(User6, (480, 230))
    screen.blit(User7, (170, 380))
    screen.blit(User8, (320, 380))
    screen.blit(User9, (480, 380))
    screen.blit(User10, (170, 530))
    screen.blit(User11, (320, 530))
    screen.blit(User12, (480, 530))
    screen.blit(icon_select(data_obj['user_icon']), (880, 200))

def change_ico(x):
    a_file = open("save.json", "r")
    data_obj = json.load(a_file)
    a_file.close()
    draw_rect(1080, 608, pygame.Color('white'), 255, 25, 100, 56, screen)
    draw_rect(1, 580, pygame.Color('black'), 255, 0, 680, 70, screen)
    screen.blit(icon_select(x), (880, 200))
    screen.blit(User1, (170, 80))
    screen.blit(User2, (320, 80))
    screen.blit(User3, (480, 80))
    screen.blit(User4, (170, 230))
    screen.blit(User5, (320, 230))
    screen.blit(User6, (480, 230))
    screen.blit(User7, (170, 380))
    screen.blit(User8, (320, 380))
    screen.blit(User9, (480, 380))
    screen.blit(User10, (170, 530))
    screen.blit(User11, (320, 530))
    screen.blit(User12, (480, 530))

u1 = Button(white, 170, 80, 100, 100)
u2 = Button(white, 320, 80, 100, 100)
u3 = Button(white, 480, 80, 100, 100)
u4 = Button(white, 170, 230, 100, 100)
u5 = Button(white, 320, 230, 100, 100)
u6 = Button(white, 480, 230, 100, 100)
u7 = Button(white, 170, 380, 100, 100)
u8 = Button(white, 320, 380, 100, 100)
u9 = Button(white, 480, 380, 100, 100)
u10 = Button(white, 170, 530, 100, 100)
u11 = Button(white, 320, 530, 100, 100)
u12 = Button(white, 480, 530, 100, 100)
t = Button(white, 760, 320, 350, 80)
done = Button(white, 900, 420, 100, 100)
remove = Button(white, 1210,  35, 24, 24)
moving_sprites = pygame.sprite.Group()
player = Player(900,420)

click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')
tayp = pygame.mixer.Sound('TypeZone/sounds/Type.mp3')
x_icon = pygame.image.load('TypeZone/Images/remove.png')
font = pygame.font.Font('TypeZone/font/monof55.ttf', 33)




def change():
    a_file = open("save.json", "r")
    data_obj = json.load(a_file)
    a_file.close()
    g = 0
    draw_rect(1280, 720, (0, 0, 0), 75, 0, 0, 0, screen)
    color = pygame.Color('#708090')
    runicon()
    pygame.display.update()
    active = False
    txt = ''
    text = ''
    i = 0
    loop = True
    while loop:
        if not active:
            if text == '':
                text = data_obj['user']
        else:
            if text != txt:
                text = txt


        if len(txt) >= 6 or i != 0:
            g = 1
            moving_sprites.add(player)
            moving_sprites.draw(screen)
        if len(txt) == 5 and i == 0:
            g = 0
            moving_sprites.remove(player)
            draw_rect(100,100, white, 255, 0, 900, 420, screen)


        screen.blit(x_icon, (1210, 35))
        draw_rect(350, 80, white, 255, 12, 760, 320, screen)
        box = pygame.draw.rect(screen, color, pygame.Rect(760, 320, 350, 80), 3, 12)
        txt_surface = font.render(text, True, color)
        win.blit(txt_surface, (box.x + (box.width / 2 - txt_surface.get_width() / 2),
                               box.y + (box.height / 2 - txt_surface.get_height() / 2)))
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if u1.isOver(pos):
                    click.play()
                    i = 1
                    change_ico(i)
                elif u2.isOver(pos):
                    click.play()
                    i = 2
                    change_ico(i)
                elif u3.isOver(pos):
                    click.play()
                    i = 3
                    change_ico(i)
                elif u4.isOver(pos):
                    click.play()
                    i = 4
                    change_ico(i)
                elif u5.isOver(pos):
                    click.play()
                    i = 5
                    change_ico(i)
                elif u6.isOver(pos):
                    click.play()
                    i = 6
                    change_ico(i)
                elif u7.isOver(pos):
                    click.play()
                    i = 7
                    change_ico(i)
                elif u8.isOver(pos):
                    click.play()
                    i = 8
                    change_ico(i)
                elif u9.isOver(pos):
                    click.play()
                    i = 9
                    change_ico(i)
                elif u10.isOver(pos):
                    click.play()
                    i = 10
                    change_ico(i)
                elif u11.isOver(pos):
                    click.play()
                    i = 11
                    change_ico(i)
                elif u12.isOver(pos):
                    click.play()
                    i = 12
                    change_ico(i)


            elif event.type == pygame.KEYDOWN:
                if active:
                    tayp.play()
                    if event.unicode.isalnum():
                        if len(text) <= 12:
                            txt += event.unicode
                    elif event.key == pygame.K_BACKSPACE:
                        txt = text[:-1]


            if event.type == pygame.MOUSEBUTTONDOWN:
                if t.isOver(pos):
                    click.play()
                    color = pygame.Color('#243240')
                    active = True

                else:
                    color = pygame.Color('#708090')
                    active = False

                if done.isOver(pos) and g == 1:
                    click.play()
                    if i != 0:
                        data_obj['user_icon'] = i
                    if len(txt) >= 6:
                        data_obj['user'] = text

                    file = open('save.json', 'w')
                    json.dump(data_obj, file, indent=4)
                    file.close()
                    loop = False


                elif remove.isOver(pos):
                    loop = False

    pygame.time.Clock().tick(60)

