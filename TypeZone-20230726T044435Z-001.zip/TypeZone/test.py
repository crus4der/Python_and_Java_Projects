import pygame, random, json
from CPE8.TypeZone.debug.Test import testing
from CPE8.TypeZone.result import result
from CPE8.TypeZone.startup import fade



font = pygame.font.Font('TypeZone/font/monof55.ttf', 33)
screen = pygame.display.set_mode((1280, 720))
pretest = 'The quick brown fox jumps over the lazy dog.'

def ave(test, inp, time, wpm):
    if len(test) <= len(inp):
        a_file = open("save.json", "r")
        data_obj = json.load(a_file)
        a_file.close()

        data_obj['divi'] += 1
        data_obj['time'] += time
        data_obj['wpm'] += round(wpm)
        data_obj['acc'] += acc(inp, test)

        data_obj['wpm'] = round(data_obj['wpm'] / data_obj['divi'])
        data_obj['acc'] = round(data_obj['acc'] / data_obj['divi'])

        file = open('save.json', 'w')
        json.dump(data_obj, file, indent=4)
        file.close()



def acc(cor_ans, test):
    x = 0
    for i in range(len(test)):
        try:
            if cor_ans[i] == test[i]:
                x += 1
            else:
                x = x
        except IndexError:
            break
    return round((x / len(test)) * 100)



def pre_test():
    testing(pretest, font, 150, 250)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 3, 400)
    result(testing.time, round(wpm), acc(testing.show, pretest))



def Easy():
    lines = open('TypeZone/challenges/Easy.txt', encoding="utf8").read().splitlines()
    myline = random.choice(lines)
    testing(myline, font, 150, 250)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 5, 400)
    result(testing.time, round(wpm), acc(testing.show, myline))

    ave(myline, testing.show, testing.time, wpm)


def Normal():
    lines = open('TypeZone/challenges/Normal.txt', encoding="utf8").read().splitlines()
    myline = random.choice(lines)
    testing(myline, font, 130, 150)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 5, 400)
    result(testing.time, round(wpm), acc(testing.show, myline))

    ave(myline, testing.show, testing.time, wpm)


def Hard():
    lines = open('TypeZone/challenges/Hard.txt', encoding="utf8").read().splitlines()
    myline = random.choice(lines)
    testing(myline, font, 130, 70)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 5, 400)
    result(testing.time, round(wpm), acc(testing.show, myline))

    ave(myline, testing.show, testing.time, wpm)

def multiplay():
    lines = open('TypeZone/challenges/Normal.txt', encoding="utf8").read().splitlines()
    myline = random.choice(lines)
    testing(myline, font, 130, 150)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 5, 400)
    result(testing.time, round(wpm), acc(testing.show, myline))

    testing(myline, font,160, 150)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    fade(1280, 720, 5, 400)
    result(testing.time, round(wpm), acc(testing.show, myline))


