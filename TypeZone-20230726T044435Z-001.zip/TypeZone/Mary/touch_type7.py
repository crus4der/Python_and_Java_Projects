import pygame


class touchType7(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Next', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('Try Pressing the Other Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Look at the keyboard picture below and press each', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('letter key on the top and bottom rows.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Try not to look at the keyboard and simply let your', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('fingers find the way.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Use a quick and light touch when pressing the keys.', True, blue_gray), (200, 325))
        pygame.display.update()