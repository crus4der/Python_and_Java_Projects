import pygame


class touchType6(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Next', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('Reaching The Other Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('With your fingers in the Home Row, use the fingers', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('closest to each key to reach the other keys.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('Look at the color coding in the picture below to see', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('which finger to use.', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('Green keys are pressed with the index finger, Blue with', True, blue_gray),(200, 325))
        self.screen.blit(self.font.render('the middle finger, purple with ring finger and dark green', True, blue_gray), (200, 350))
        self.screen.blit(self.font.render('ones with the pinky finger.', True, blue_gray), (200, 375))
        pygame.display.update()