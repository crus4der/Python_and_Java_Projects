from TypeZone.Mary.first_page import *
from TypeZone.Mary.touch_type import *
from TypeZone.Mary.touch_type2 import *
from TypeZone.Mary.touch_type3 import *
from TypeZone.Mary.touch_type4 import *
from TypeZone.Mary.touch_type5 import *
from TypeZone.Mary.touch_type6 import *
from TypeZone.Mary.touch_type7 import *
from TypeZone.Mary.touch_type8 import *
from TypeZone.Mary.lesson1 import *
from TypeZone.Mary.lesson2 import Lesson2
from TypeZone.Mary.lesson3 import Lesson3
from TypeZone.Mary.lesson4 import Lesson4
from TypeZone.Mary.lesson5 import Lesson5
from TypeZone.Mary.review import Review
from TypeZone.Mary.text_lesson import *
from TypeZone.Mary.function import *
from TypeZone.Mary.Tester2 import testing2
from TypeZone.Mary.Tester3 import testing3
from TypeZone.Mary.Tester4 import testing4
from TypeZone.Mary.Tester5 import testing5
from TypeZone.Mary.Tester_review import testing_review

pygame.init()

screen = pygame.display.set_mode((1280, 720))
background = pygame.image.load(os.path.join('Images',"background.png"))

white = (255, 255, 255)
black = (0, 0, 0)
blue_gray = (51, 63, 80)
button_1 = Button((255, 255, 255), 25, 25, 175, 60)
button_2 = Button((255, 255, 255), 1125, 610, 130, 65)

def main():
    pass
