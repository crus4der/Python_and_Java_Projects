from TypeZone.Mary.Images import *
from TypeZone.Mary.first_page import *
from TypeZone.Mary.touch_type import *
from TypeZone.Mary.touch_type2 import *
from TypeZone.Mary.touch_type3 import *
from TypeZone.Mary.touch_type4 import *
from TypeZone.Mary.touch_type5 import *
from TypeZone.Mary.touch_type6 import *
from TypeZone.Mary.touch_type7 import *
from TypeZone.Mary.touch_type8 import *
from TypeZone.Mary.lesson1 import *
from TypeZone.Mary.lesson2 import Lesson2
from TypeZone.Mary.lesson3 import Lesson3
from TypeZone.Mary.lesson4 import Lesson4
from TypeZone.Mary.lesson5 import Lesson5
from TypeZone.Mary.review import Review
from TypeZone.Mary.text_lesson import *
from TypeZone.Mary.function import *
from TypeZone.Mary.Tester2 import testing2
from TypeZone.Mary.Tester3 import testing3
from TypeZone.Mary.Tester4 import testing4
from TypeZone.Mary.Tester5 import testing5
from TypeZone.Mary.Tester_review import testing_review

# initialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((1280, 720))

background = pygame.image.load('Images/background.png')

# title and icon
pygame.display.set_caption("Lesson Module")
icon = pygame.image.load('Images/Icon.png')
pygame.display.set_icon(icon)

# colors
white = (255, 255, 255)
black = (0, 0, 0)
blue_gray = (51, 63, 80)
button_1 = Button((255, 255, 255), 25, 25, 175, 60)
button_2 = Button((255, 255, 255), 1125, 610, 130, 65)


def first_Page():
    color = black
    screen.fill(white)
    fp_text = firstPage()
    fp_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 25, 130, 60), 2, 12)
    button_3 = Button((255, 255, 255), 1125, 25, 130, 60)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(kb, (250, 450))
    lesson(next, (1210, 630))
    lesson(ff, (1200, 45))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    screen.fill(black)

                elif  button_3.isOver(pos):
                    print('click')
                    loop = False
                    run_lesson()

                elif button_2.isOver(pos):
                    loop = False
                    touch_Type()




def touch_Type():
    color = black
    screen.fill(white)
    tt_text = touchType()
    tt_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(kb, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    first_Page()
                elif button_2.isOver(pos):
                    loop = False
                    touch_Type2()




def touch_Type2():
    color = black
    screen.fill(white)
    tt2_text = touchType2()
    tt2_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(kbh, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type()
                elif button_2.isOver(pos):
                    loop = False
                    touch_Type3()


def touch_Type3():
    color = black
    screen.fill(white)
    tt3_text = touchType3()
    tt3_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(lefth, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type2()

                elif  button_2.isOver(pos):
                    loop = False
                    touch_Type4()


def touch_Type4():
    color = black
    screen.fill(white)
    tt4_text = touchType4()
    tt4_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(kbh, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type3()

                elif button_2.isOver(pos):
                    loop = False
                    touch_Type5()



def touch_Type5():
    color = black
    screen.fill(white)
    tt5_text = touchType5()
    tt5_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(kbh, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type4()

                elif button_2.isOver(pos):
                    loop = False
                    touch_Type6()



def touch_Type6():
    color = black
    screen.fill(white)
    tt6_text = touchType6()
    tt6_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(full, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type5()

                elif  button_2.isOver(pos):
                    loop = False
                    touch_Type7()



def touch_Type7():
    color = black
    screen.fill(white)
    tt7_text = touchType7()
    tt7_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(full, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type6()

                elif button_2.isOver(pos):
                    loop = False
                    touch_Type8()



def touch_Type8():
    color = black
    screen.fill(white)
    tt8_text = touchType8()
    tt8_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(inf, (800, 120))
    lesson(full, (250, 450))
    lesson(next, (1210, 630))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    touch_Type7()

                elif button_2.isOver(pos):
                    loop = False
                    run_lesson()



def lesson_1():
    color = black
    l1_text = Lesson1()
    l1_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(kbh, (250, 450))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()

                elif button_2.isOver(pos):
                    loop = False
                    testing1()


def lesson_2():
    color = black
    l2_text = Lesson2()
    l2_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(kbt, (250, 450))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()

                elif button_2.isOver(pos):
                    loop = False
                    testing2()


def lesson_3():
    color = black
    l3_text = Lesson3()
    l3_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(kbb, (250, 450))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()

                elif  button_2.isOver(pos):
                    loop = False
                    testing3()


def lesson_4():
    color = black
    l4_text = Lesson4()
    l4_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(kbn, (250, 450))
    pygame.display.flip()
    loop = False
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()


                elif button_2.isOver(pos):
                    loop = False
                    testing4()


def lesson_5():
    color = black
    l5_text = Lesson5()
    l5_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(kbs, (250, 450))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()

                elif button_2.isOver(pos):
                    loop = False
                    testing5()



def review_():
    color = black
    r_text = Review()
    r_text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    pygame.draw.rect(screen, color, pygame.Rect(1125, 610, 130, 65), 2, 12)
    lesson(back, (40, 45))
    lesson(full, (250, 450))
    pygame.display.flip()
    loop = True
    while loop:
        pos = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_1.isOver(pos):
                    loop = False
                    run_lesson()

                elif button_2.isOver(pos):
                    loop = False
                    testing_review()



def run_lesson():
    color = black
    text = Pane()
    text.addText()
    pygame.draw.rect(screen, color, pygame.Rect(25, 25, 175, 60), 2, 12)
    lesson(back, (40, 45))
    lesson(lesson1, (125, 120))
    lesson(lesson2, (510, 120))
    lesson(lesson3, (895, 120))
    lesson(lesson4, (125, 420))
    lesson(lesson5, (510, 420))
    lesson(review, (895, 420))
    pygame.display.update()
    loop = True
    while loop:
        mx, my = pygame.mouse.get_pos()
        close()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if 25 < mx < 200 and 25 < my < 85:
                    loop = False
                    first_Page()

                elif 155 < mx < 375 and 134 < my < 294:
                    loop = False
                    lesson_1()

                elif 530 < mx < 884 and 134 < my < 294:
                    loop = False
                    lesson_2()

                elif 905 < mx < 1125 and 134 < my < 294:
                    loop = False
                    lesson_3()

                elif  155 < mx < 375 and 427 < my < 587:
                    loop = False
                    lesson_4()

                elif 530 < mx < 884 and 427 < my < 587:
                    loop = False
                    lesson_5()
                elif 905 < mx < 1125 and 427 < my < 587:
                    loop = False
                    review_()


def close():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def main():
    while True:
        screen.fill(white)
        screen.blit(background, (0, 0))
        pygame.display.update()
        first_Page()

        pygame.display.flip()
        close()


main()