import pygame


class Pane(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.mainFont.render('Lessons', True, blue_gray), (545, 50))
        self.screen.blit(self.font.render('Go Back', True, black), (75, 40))
        pygame.display.update()