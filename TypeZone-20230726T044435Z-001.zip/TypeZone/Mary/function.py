import pygame, sys
pygame.init()

screen = pygame.display.set_mode((1280, 720))

def blit_text(surface, text, pos, font, color):
    words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
    space = font.size(' ')[0]  # The width of a space.
    x, y = pos
    width, height = surface.get_size()
    max_width = width - x
    wid, hei = 0, 0
    for line in words:
        for word in line:
            word_surface = font.render(word, True, color)
            word_width, word_height = word_surface.get_size()
            hei = word_height
            if x + word_width >= max_width:
                x = pos[0]  # Reset the x.
                y += word_height + 10  # Start on new row.
            for let in word:
                let_surface = font.render(let, True, color)
                let_width, let_height = let_surface.get_size()
                wid = let_width
                surface.blit(let_surface, (x, y))
                x += let_width + space
            x += wid + space
        # x = pos[0]  # Reset the x.
        # y += hei  # Start on new row.


#def rect(screen, pos, color, width, height, alpha):
#    surf_rect = pygame.Surface((width, height), pygame.SRCALPHA)
#    surf_rect.set_alpha(alpha)
#    surf_rect.fill(color)
#
#    screen.blit(surf_rect, pos)
#    pygame.display.update()


class Button:
    def __init__(self, color, x, y, width, height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def isOver(self, pos):
        # Pos is the mouse position or a tuple of (x,y) coordinates
        if self.x < pos[0] < self.x + self.width:
            if self.y < pos[1] < self.y + self.height:
                return True

    def draw_rect(self, alpha, screen, roundness):
        surf_rect = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        surf_rect.set_alpha(alpha)
        pygame.draw.rect(screen, self.color, pygame.Rect(self.x, self.y, self.width, self.height), border_radius = roundness)
        pygame.display.update()


class Rect(pygame.sprite.Sprite):
    def init(self, width, height, color,alpha):
        self.width = width
        self.height = height
        self.color = color
        self.alpha = alpha

        pygame.sprite.Sprite.init(self)
        self.original_image = pygame.Surface((self.width, self.height))
        self.original_image.fill((255, 255, 255))
        self.image = self.original_image
        self.rect = self.image.get_rect()

    def set_rounded(self, roundness):
        size = self.original_image.get_size()
        self.rect_image = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.rect(self.rect_image, self.color, (0, 0, *size), border_radius=roundness)

        self.image = self.original_image.copy().convert_alpha()
        self.image.set_alpha(self.alpha)
        self.image.blit(self.rect_image, (0, 0), None, pygame.BLEND_RGBA_MIN)


def close():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

def lesson(name, def_pos):
    screen.blit(name, def_pos)
    return

