from TypeZone.Mary.Tester1 import *
from TypeZone.Mary.function import close
from TypeZone.Mary.images import *

blue_gray = (51, 63, 80)
black = (0, 0, 0)
white = (255, 255, 255)

class Review(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Start!', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('Review of Everything You Have Practiced', True, blue_gray), (250, 50))
        self.screen.blit(self.font.render('This part of the module is just a review of ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('everything in this lesson module.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('Hopefully, after you finished this last activity,', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('you will get better at ', True, blue_gray), (225, 275))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 300))