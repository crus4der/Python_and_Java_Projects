import pygame


class touchType2(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Next', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('It Begins With The Home Keys', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('Stop bouncing around the keyboard and find the best', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('position of your fingers.', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('The Home Keys, also called \"the home row\", are the ', True, blue_gray), (200, 250))
        self.screen.blit(self.font.render('keys A S D F and J K L ;. They\'re the starting point for', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('touch typing and the home base for each finger.', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Here they are on the keyboard:', True, blue_gray), (200, 350))
        pygame.display.update()