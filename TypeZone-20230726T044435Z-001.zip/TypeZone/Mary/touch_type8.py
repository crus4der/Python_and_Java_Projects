import pygame


class touchType8(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Next', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('The Lesson Module', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('How did that feel? Your next stop is the Lesson Module', True, blue_gray), (200, 175))
        self.screen.blit(self.font.render('where you\'ll get to learn, practice and try touch typing', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('more.', True, blue_gray), (200, 225))
        self.screen.blit(self.font.render('Try to use all fingers from their home row position, but', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('don\'t stress about speed and accuracy', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Are you ready?', True, blue_gray), (200, 350))
        pygame.display.update()