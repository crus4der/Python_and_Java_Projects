import pygame
from CPE8.TypeZone.functions import rect
pygame.init()


SIZE = WIDTH, HEIGHT = (1280, 720)
FPS = 30
screen = pygame.display.set_mode(SIZE)
clock = pygame.time.Clock()

get = ''

txt = "Jjjj Jjjj Jjjj Ffff Ffff Ffff jJj jJj jJj fFf fFf kK dD lL sS aA Kk Dd Ll Ss Aa " \
      "uU rR iI eE oO wW pP qQ Uu Rr Ii Ee Oo Ww Pp Qq " \
      "mM vV nN cC bb xX zZ Mm Vv Nn Cc Bb Xx Zz " \
      "The New Year 2019 begins on Tue., Jan. 1. " \
      "I don’t believe it!! " \
      "They are buying a new car!?"

def blit_text(surface, text, pos, font, color, change):
    words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
    space = font.size(' ')[0]  # The width of a space.
    max_width, max_height = surface.get_size()
    x, y = pos
    max_width = max_width - x
    wid, hei = 0, 0
    for line in words:
        for word in line:
            word_surface = font.render(word, True, color)
            word_width, word_height = word_surface.get_size()
            hei = word_height
            if x + word_width >= max_width:

                x = pos[0]  # Reset the x.
                y += word_height + 17  # Start on new row.
            for let in word:
                let_surface = font.render(let, True, pygame.Color('#4a4a4a'))
                let_width, let_height = let_surface.get_size()
                wid = let_width
                surface.blit(let_surface, (x, y))
                x += let_width + space
            x += wid



        #x = pos[0]  # Reset the x.
        #y += hei  # Start on new row.


def testing5():

    font = pygame.font.Font('monof55.ttf', 33)
    def_color = pygame.Color('#4a4a4a')
    correct_color = pygame.Color('green')
    wrong_color = pygame.Color('red')

    error = 1
    i = 0
    x = 0
    total_width = 0
    add_height = 0
    show = ''

    done = False
    while not done:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
        screen.fill((250,250,250))
        blit_text(screen, txt, (110, 100), font, def_color, def_color)
        #Spygame.display.update()

        typing = True
        while typing:

            if x == len(txt):
                done = True
            pos = 110, 100
            p_x, p_y = pos
            space = font.size(' ')[0]
            post = (p_x, p_y)
            max_width = screen.get_width()
            max_width = max_width

            if x == len(txt):
                typing = False

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    quit()

                if event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_SPACE:
                        if txt[x] == ' ':
                            reduce_surf = font.render(txt[x - 1], True, correct_color)
                            get_width = reduce_surf.get_width()
                            text_surf = font.render(txt[x], True, correct_color)
                            width, height = text_surf.get_size()
                            if x == 0:
                                screen.blit(text_surf, post)
                            else:
                                #blit_char(screen,p_x + total_width, p_y + add_height, text_surf)
                                rect(screen, (p_x - 7.5 + total_width, p_y + add_height), correct_color, width, height - 3 , 35)
                                rect(screen, (p_x - 7.5 + total_width, p_y + 35 + add_height), correct_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                            error = 1
                            total_width += space

                        else:
                            if error <= 2:

                                text_surf = font.render(txt[x], True, wrong_color)
                                width, height = text_surf.get_size()
                                rect(screen, (p_x + total_width - 2, p_y + add_height), wrong_color, width + 4, height - 3, 35)
                                rect(screen, (p_x + total_width, p_y + 35 + add_height), wrong_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                                x += 1
                                error += 2
                                total_width += width + space

                        if error < 2:
                            x += 1
                            show += event.unicode
                        else:
                            x = x

                    elif event.unicode:
                        if event.unicode == txt[x]:
                            text_surf = font.render(txt[x], True, correct_color)
                            width, height = text_surf.get_size()
                            rect(screen, (p_x + total_width - 2, p_y + add_height), correct_color, width + 4, height - 3, 35)
                            rect(screen, (p_x + total_width, p_y + 35 + add_height), correct_color, width, 2, 100)
                            screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                            total_width += space + width
                            error = 1

                        elif txt[x] != ' ':
                            if error <= 2:

                                text_surf = font.render(txt[x], True, wrong_color)
                                width, height = text_surf.get_size()

                                rect(screen, (p_x + total_width - 2, p_y + add_height), wrong_color, width + 4, height - 3,
                                     35)
                                rect(screen, (p_x + total_width, p_y + 35 + add_height), wrong_color, width, 2, 100)
                                screen.blit(text_surf, (p_x + total_width, p_y + add_height))
                                error += 2
                                x += 1

                                total_width += space + width

                        else:
                            if error < 2:

                                reduce_surf = font.render(txt[x + 1], True, wrong_color)
                                get_width, get_height = reduce_surf.get_size()
                                surf = font.render(txt[x], True, wrong_color)
                                width, height = reduce_surf.get_size()
                                rect(screen, (p_x + total_width - 8, p_y + add_height), wrong_color, get_width, get_height - 3, 35)
                                rect(screen, (p_x + total_width - 8, p_y + 35 + add_height), wrong_color, get_width, 2, 100)
                                error += 1
                                x += 1
                                total_width += space

                        if error < 2:
                            x += 1
                            show += event.unicode
                        else:
                            x = x

                    #sp = show.split()
                    sp = txt.split(' ')
                    #print(len(sp))
                    #show_sp = get.split(' ')
                    if txt[x - 1] == ' ':

                        char_surf = font.render(txt[x], True, def_color)
                        char_width, char_height = char_surf.get_size()
                        if i + 1 <= len(sp):
                            word_surf = font.render(sp[i+1], True, def_color)
                            word_width, word_height = word_surf.get_size()
                        else:
                            word_width = 0
                        #print(word_width)

                        if total_width + p_x + word_width - space >= max_width - p_x:
                            total_width = 0
                            add_height += char_height + 17
                        if error <= 2:
                            if event.unicode:
                                i += 1
                                error += 1
                        print(error)

            pygame.display.flip()
            clock.tick(60)
            done = True