import pygame


class touchType5(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        white = (255, 255, 255)
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        blue_gray = (51, 63, 80)
        black = (0, 0, 0)
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Next', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('Your Fingers Are Now On The Home Row!', True, blue_gray), (250, 50))
        self.screen.blit(self.font.render('From now on, the Home Row will be the basic position for', True, blue_gray), (200, 200))
        self.screen.blit(self.font.render('your hands when you type.', True, blue_gray), (200, 225))
        self.screen.blit(self.font.render('TIP! When typing, keep your wrists up and your fingers', True, blue_gray), (200, 275))
        self.screen.blit(self.font.render('slightly curled and relaxed - you\'ll feel more comfortable.', True, blue_gray), (200, 300))
        self.screen.blit(self.font.render('Next up, the secondary keys...', True, blue_gray),(200, 350))
        pygame.display.update()