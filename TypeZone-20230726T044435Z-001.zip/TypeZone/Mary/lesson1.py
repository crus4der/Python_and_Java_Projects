from TypeZone.Mary.Tester1 import *
from TypeZone.Mary.function import close
from TypeZone.Mary.images import *

blue_gray = (51, 63, 80)
black = (0, 0, 0)
white = (255, 255, 255)

class Lesson1(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)
        pygame.display.update()

    def addText(self):
        self.screen.blit(self.optFont.render('Go Back', True, black), (75, 40))
        self.screen.blit(self.optFont.render('Start!', True, black), (1145, 625))
        self.screen.blit(self.mainFont.render('Learning The Home Row', True, blue_gray), (300, 50))
        self.screen.blit(self.font.render('This lesson will focus on using the ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('Home Row keys.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('on to typing full words and some short text.', True, blue_gray), (225, 275))
        self.screen.blit(self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 325))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 350))