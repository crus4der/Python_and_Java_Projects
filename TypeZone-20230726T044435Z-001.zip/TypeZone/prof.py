import pygame, json, sys
from CPE8.TypeZone.functions import draw_rect, Button
from CPE8.TypeZone.profile_graph import time, wpm, accuracy
from CPE8.TypeZone.change_icon import change
from CPE8.TypeZone.icons import icon_select
from CPE8.TypeZone.setting_functions import beta_pop, typezone_pop, feedback_pop, power


screen = pygame.display.set_mode((1280, 720))
pygame.init()

color = pygame.Color('white')
clr_b = pygame.Color('#243240')
click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')

prof_txt = 'PROFILE'
achi_txt = 'ACHIEVEMENTS'
sett_txt = 'SETTINGS'

achi_box = pygame.image.load('TypeZone/Profile_Module/Images/achievements__.png')

hb = Button(color, 680, 40, 48, 48)
b1 = Button(color, 46, 45, 200, 40)
b2 = Button(color, 251, 45, 200, 40)
b3 = Button(color, 456, 45, 200, 40)
on = Button(color, 435, 450, 32, 32)

def icon_blit(x):
    home = pygame.transform.scale(pygame.image.load('TypeZone/Images/home.png'), (48, 48))
    screen.blit(home, (680, 40))
    if x == 0:
        user = pygame.transform.scale(pygame.image.load('TypeZone/Images/user_b.png'), (24, 24))
        achi = pygame.transform.scale(pygame.image.load('TypeZone/Images/achi_w.png'), (24, 24))
        sett = pygame.transform.scale(pygame.image.load('TypeZone/Images/sett_w.png'), (24, 24))
        screen.blit(user, (80, 52))
        screen.blit(achi, (256, 52))
        screen.blit(sett, (477, 52))

    elif x == 1:
        user = pygame.transform.scale(pygame.image.load('TypeZone/Images/user_w.png'), (24, 24))
        achi = pygame.transform.scale(pygame.image.load('TypeZone/Images/achi_b.png'), (24, 24))
        sett = pygame.transform.scale(pygame.image.load('TypeZone/Images/sett_w.png'), (24, 24))
        screen.blit(user, (80, 52))
        screen.blit(achi, (256, 52))
        screen.blit(sett, (477, 52))

    elif x == 2:
        user = pygame.transform.scale(pygame.image.load('TypeZone/Images/user_w.png'), (24, 24))
        achi = pygame.transform.scale(pygame.image.load('TypeZone/Images/achi_w.png'), (24, 24))
        sett = pygame.transform.scale(pygame.image.load('TypeZone/Images/sett_b.png'), (24, 24))
        screen.blit(user, (80, 52))
        screen.blit(achi, (256, 52))
        screen.blit(sett, (477, 52))





def text_blit(clr, clr1 , clr2):

    font = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 18)
    text_surf = font.render(prof_txt, True, clr)
    text_surf1 = font.render(achi_txt, True, clr1)
    text_surf2 = font.render(sett_txt, True, clr2)


    screen.blit(text_surf, (b1.x + (b1.width/2 - text_surf.get_width() / 2),
                            b1.y + (b1.height/2 - text_surf.get_height() / 2)))

    screen.blit(text_surf1, (b2.x + (b2.width / 2 - text_surf1.get_width() / 2),
                            b2.y + (b2.height / 2 - text_surf1.get_height() / 2)))

    screen.blit(text_surf2, (b3.x + (b3.width / 2 - text_surf2.get_width() / 2),
                             b3.y + (b3.height / 2 - text_surf2.get_height() / 2)))


def profile_blit(user, user_icon):
    font = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 20)
    fontc = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 23)
    txtc = fontc.render(user, True, clr_b)
    txt = font.render('OVERALL PERFORMANCE', True, clr_b)
    edit_icon = pygame.image.load('TypeZone/Images/edit.png')


    loop = True
    while loop:

        # Background {
        screen.fill((255, 255, 255))
        draw_rect(1280, 720, pygame.Color('#92b6db'), 150, 0, 0, 0, screen)
        draw_rect(1, 600, clr_b, 255, 0, 350, 100, screen)
        draw_rect(800, 1, clr_b, 255, 0, 415, 175, screen)
        screen.blit(txt, (715, 140 ))
        screen.blit(user_icon, (315/2 - 50, 150 + 150))
        screen.blit(txtc, (315/2 - txtc.get_width()/2, 290 + 120))
        # {
        edit_button = Button(color, 315/2 + txtc.get_width()/2 + 20,290 + 120, 24, 24)
        screen.blit(edit_icon, (315/2 + txtc.get_width()/2 + 20, 290 + 120))

        # }
        # }
        a_file = open("save.json", "r")
        data_obj = json.load(a_file)
        a_file.close()

        # Graphs {
        time(round(data_obj['time']))
        wpm(round(data_obj['wpm']))
        accuracy(round(data_obj['acc']))
        # }

        draw_rect(622, 50, pygame.Color('#243240'), 255, 12, 40, 40, screen)
        draw_rect(190, 40, color, 255, 0, 56, 45, screen)
        draw_rect(200, 40, color, 255, 10, 46, 45, screen)
        text_blit(clr_b, color, color)
        icon_blit(0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if b2.isOver(pos):
                    click.play()
                    loop = False
                    achievements(user, user_icon)

                elif b3.isOver(pos):
                    click.play()
                    loop = False
                    settings(user, user_icon)

                elif hb.isOver(pos):
                    click.play()
                    loop = False


                elif edit_button.isOver(pos):
                    click.play()
                    loop = False
                    change()

                    with open('save.json', 'r') as users:
                        data = json.load(users)
                    profile_blit(data['user'], icon_select(data['user_icon']))

        pygame.time.Clock().tick(60)

def achievements(user, user_icon):
    font = pygame.font.SysFont('Calibri', 60, True)
    t_surf = font.render('NOT AVAILABLE ON BETA', True, pygame.Color('#FFFF33'))
    col = pygame.Color('#243240')
    loop = True
    while loop:

        screen.fill(color)
        screen.blit(achi_box, (40, 50))
        draw_rect(1280, 720, clr_b, 120, 0, 0, 0 , screen)
        draw_rect(800, 80, col, 255, 10, 230, 720 / 2 - t_surf.get_height()/2 -13, screen)
        screen.blit(t_surf, (1280 / 2 - t_surf.get_width()/2, 720 / 2 - t_surf.get_height()/2))


        draw_rect(622, 50, pygame.Color('#243240'), 255, 12, 40, 40, screen)
        draw_rect(200, 40, color, 255, 0, 251, 45, screen)
        text_blit(color, clr_b, color)
        icon_blit(1)

        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if b1.isOver(pos):
                    click.play()
                    loop = False
                    profile_blit(user, user_icon)

                elif b3.isOver(pos):
                    click.play()
                    loop = False
                    settings(user, user_icon)

                elif hb.isOver(pos):
                    click.play()
                    loop = False
        pygame.time.Clock().tick(60)

def settings(user, user_icon):
    s1 = Button(color, 45, 165, 1200, 95)
    s2 = Button(color, 45, 290, 1200, 95)
    s4 = Button(color, 44, 542, 1195, 95)
    p = Button(color, 1180, 50, 32, 32)
    powr = pygame.image.load('TypeZone/Images/power-off.png')
    sound_pos = (440, 450)
    loop = True
    while loop:

        screen.fill(color)
        sound = pygame.image.load('TypeZone/Images/check.png')
        sett = pygame.image.load('TypeZone/Images/setting.png')
        screen.blit(sett, (0, 0))
        screen.blit(powr, (1180, 50))
        with open('save.json', 'r') as snd:
            sound_sys = json.load(snd)
        if sound_sys['vol'] == 0.2:
            screen.blit(sound, sound_pos)
        draw_rect(622, 50, pygame.Color('#243240'), 255, 12, 40, 40, screen)
        draw_rect(190, 40, color, 255, 0, 456, 45, screen)
        draw_rect(200, 40, color, 255, 12, 456, 45, screen)
        text_blit(color, color, clr_b)
        icon_blit(2)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if b1.isOver(pos):
                    click.play()
                    loop = False
                    profile_blit(user, user_icon)

                elif b2.isOver(pos):
                    click.play()
                    loop = False
                    achievements(user, user_icon)

                elif hb.isOver(pos):
                    click.play()
                    loop = False

                elif on.isOver(pos):
                    click.play()
                    with open('save.json', 'r') as sounds:
                        sound_rate = json.load(sounds)
                    if sound_rate['vol'] == 0.2:
                        sound_pos = (-50, - 50)
                        sound_rate['vol'] = 0
                        pygame.mixer.music.set_volume(sound_rate['vol'])

                    else:
                        sound_pos = (440, 450)
                        sound_rate['vol'] = 0.2
                        pygame.mixer.music.set_volume(sound_rate['vol'])


                    file = open('save.json', 'w')
                    json.dump(sound_rate, file, indent=4)
                    file.close()

                elif s1.isOver(pos):
                    click.play()
                    beta_pop()
                elif s2.isOver(pos):
                    click.play()
                    typezone_pop()
                elif s4.isOver(pos):
                    click.play()
                    feedback_pop()
                elif p.isOver(pos):
                    click.play()
                    power()






        pygame.time.Clock().tick(60)


