import json, sys
from CPE8.TypeZone.icons import *
from CPE8.TypeZone.functions import *

import os, json

pygame.init()

# Windows Screen


# Icon Button
icon1 = Button((0,0,0), 210, 400, 100 ,100)
icon2 = Button((0,0,0), 360, 400, 100 ,100)
icon3 = Button((0,0,0), 510, 400, 100 ,100)
icon4 = Button((0,0,0), 660, 400, 100 ,100)
icon5 = Button((0,0,0), 810, 400, 100 ,100)
icon6 = Button((0,0,0), 960, 400, 100 ,100)
icon7 = Button((0,0,0), 210, 550, 100 ,100)
icon8 = Button((0,0,0), 360, 550, 100 ,100)
icon9 = Button((0,0,0), 510, 550, 100 ,100)
icon10 = Button((0,0,0), 660, 550, 100 ,100)
icon11 = Button((0,0,0), 810, 550, 100 ,100)
icon12 = Button((0,0,0), 960, 550, 100 ,100)

# Text Button

input_box = Button((255, 255, 255), 400, 235, 475, 85)
play_button = Button((255, 255, 255), 885, 245, 64, 64)

window = pg.display.set_mode((1280, 1080))

# object
rect_object = Rectangle()
rect_object.set_rounded(12)
rect_object.rect.center = (637.5, 277.5)
group = pg.sprite.Group(rect_object)
play = pygame.image.load('TypeZone/Images/play.png')

moving_sprites = pygame.sprite.Group()
player = Player(885,245)

click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')


def reset():
    win.fill((255,255,255))


select_icon = 0
def select():
    icon_change()
    if select_icon == 1:
        icon(User1, (585, 100))
        return User1

    elif select_icon == 2:
        icon(User2, (585, 100))
        return User2

    elif select_icon == 3:
        icon(User3, (585, 100))
        return User3

    elif select_icon == 4:
        icon(User4, (585, 100))
        return User4

    elif select_icon == 5:
        icon(User5, (585, 100))
        return User5

    elif select_icon == 6:
        icon(User6, (585, 100))
        return User6

    elif select_icon == 7:
        icon(User7, (585, 100))
        return User7

    elif select_icon == 8:
        icon(User8, (585, 100))
        return User8

    elif select_icon == 9:
        icon(User9, (585, 100))
        return User9

    elif select_icon == 10:
        icon(User10, (585, 100))
        return User10

    elif select_icon == 11:
        icon(User11, (585, 100))
        return User11

    elif select_icon == 12:
        icon(User12, (585, 100))
        return User12

    else:
        icon(Main_user, (585, 100))


def profile():
    pygame.font.init()
    text = 'Enter Username'
    profile.save = ''
    color_inactive = pygame.Color('#708090')
    color_active = pygame.Color('#243240')
    color = color_inactive
    clock = pygame.time.Clock()
    pygame.time.delay(1000)
    font = pygame.font.Font('TypeZone/font/Ebisu-Light.ttf', 30)
    txt = 0

    # Boolean values
    active = False
    done = False
    end = False


    run_icon()
    pygame.display.update()
    while not done:
        global select_icon
        group.draw(window)

        if txt >= 6 and select_icon != 0:
            moving_sprites.add(player)
            moving_sprites.draw(win)
        if txt == 5 and select_icon == 0:
            moving_sprites.remove(player)

        box = pygame.draw.rect(win, color, pygame.Rect(400, 235, 475, 85), 3, 12)
        txt_surface = font.render(text, True, color)
        win.blit(txt_surface, (box.x + (box.width / 2 - txt_surface.get_width() / 2),
                               box.y + (box.height / 2 - txt_surface.get_height() / 2)))

        pygame.display.flip()




        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()


            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


            if event.type == pygame.MOUSEBUTTONDOWN:

                if input_box.isOver(pos):
                    # Toggle the active variable.
                    click.play()
                    active = not active
                    if text == 'Enter Username':
                        text = ''

                    elif not active:
                        if text == '':
                            text = 'Enter Username'


                else:
                    if text == '':
                        text = 'Enter Username'
                    active = end

                    if select_icon != 0 and len(text) >= 6 and text != 'Enter Username':
                        if play_button.isOver(pos):
                            click.play()
                            data = {'user': text, 'user_icon': select_icon, 'time': 0, 'wpm': 0, 'acc': 0, 'divi': 0, 'vol': 0.2, 'tt': 0}
                            with open('save.json', 'w') as scorefile:
                                json.dump(data, scorefile, indent=4)
                            done = True

                color = color_active if active else color_inactive

            if event.type == pygame.KEYDOWN:
                type_text = pygame.mixer.Sound('TypeZone/sounds/Type.mp3')
                data = {'user': text, 'user_icon': select_icon, 'time': 0, 'wpm': 0, 'acc': 0, 'divi': 0, 'vol': 0.2, 'tt': 0}


                if active:
                    if event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                        if txt != 0:
                            type_text.play()
                            txt = txt - 1
                        if txt == 5:
                            reset()
                            select()


                    else:
                        txt_len = len(text)
                        if txt_len <= 12:
                            if event.unicode.isalnum():
                                type_text.play()
                                text += event.unicode
                                txt += 1
                if event.key == pygame.K_RETURN:
                    if select_icon != 0 and len(text) >= 6 and text != 'Enter Username':
                        type_text.play()
                        with open('save.json', 'w') as scorefile:
                            json.dump(data, scorefile, indent=4)
                        done = True


            if event.type == pygame.MOUSEMOTION:
                if not active:
                    if input_box.isOver(pos):
                        activex = not end
                    else:
                        activex = end

                    color = color_active if activex else color_inactive


    # Mouse Event / Mouse Clicks
            if event.type == pygame.MOUSEBUTTONDOWN:



                # Icon 1 click
                if icon1.isOver(pos):
                    select_icon = 1
                    click.play()
                    select()



                # Icon 2 click
                elif icon2.isOver(pos):
                    select_icon = 2
                    click.play()
                    select()

                # Icon 3 click
                elif icon3.isOver(pos):
                    select_icon = 3
                    click.play()
                    select()

                # Icon 4 click
                elif icon4.isOver(pos):
                    select_icon = 4
                    click.play()
                    select()

                # Icon 5 click
                elif icon5.isOver(pos):
                    select_icon = 5
                    click.play()
                    select()

                # Icon 6 click
                elif icon6.isOver(pos):
                    select_icon = 6
                    click.play()
                    select()


                # Icon 7 click
                elif icon7.isOver(pos):
                    select_icon = 7
                    click.play()
                    select()


                # Icon 8 click
                elif icon8.isOver(pos):
                    select_icon = 8
                    click.play()
                    select()


                # Icon 9 click
                elif icon9.isOver(pos):
                    select_icon = 9
                    click.play()
                    select()


                # Icon 10 click
                elif icon10.isOver(pos):
                    select_icon = 10
                    click.play()
                    select()


                # Icon 11 click
                elif icon11.isOver(pos):
                    select_icon = 11
                    click.play()
                    select()


                # Icon 12 click
                elif icon12.isOver(pos):
                    select_icon = 12
                    click.play()
                    select()

            #s = pygame.Surface((475,85))
            #s.set_alpha(0)
            #win.fill((255, 255, 255, 128), (400, 235, 475, 85 ))
            #win.blit(s, (400, 235))

            clock.tick(60)

