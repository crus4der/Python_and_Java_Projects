import pygame, os, sys
from CPE8.TypeZone.functions import draw_rect, draw_text, Button
from CPE8.TypeZone.test import Easy, Normal, Hard

pygame.init()
screen = pygame.display.set_mode((1280,720))


def challenge():
    click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')
    clock = pygame.time.Clock()
    show = True
    screen.fill((255, 255, 255))
    home_icon = pygame.image.load('TypeZone/Images/home.png')

    # button
    easy = Button((0,0,0), 130, 185, 300, 350)
    normal = Button((0, 0, 0), 490, 185, 300, 350)
    hard = Button((0, 0, 0), 850, 185, 300, 350)
    home = Button((255, 255, 255), 1180, 40, 64, 64)




    while show:


        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEMOTION:

                if easy.isOver(pos):
                    screen.fill((255, 255, 255))
                    draw_rect(300, 350, pygame.Color('#FFFF33'), 255, 10, 110, 200, screen)

                elif normal.isOver(pos):
                    screen.fill((255, 255, 255))
                    draw_rect(300, 350, pygame.Color('#FFFF33'), 255, 10, 470, 200, screen)

                elif hard.isOver(pos):
                    screen.fill((255, 255, 255))
                    draw_rect(300, 350, pygame.Color('#FFFF33'), 255, 10, 830, 200, screen)

                else:
                    screen.fill((255, 255, 255))


            elif event.type == pygame.MOUSEBUTTONDOWN:

                if home.isOver(pos):
                    click.play()
                    show = False

                elif easy.isOver(pos):
                    click.play()
                    pygame.mixer.music.pause()
                    Easy()

                elif normal.isOver(pos):
                    click.play()
                    pygame.mixer.music.pause()
                    Normal()

                elif hard.isOver(pos):
                    click.play()
                    pygame.mixer.music.pause()
                    Hard()

        draw_rect(64,64, pygame.Color('white'), 255, 0, 1180, 40, screen)
        screen.blit(home_icon, (1180, 40))

        # blue rect
        draw_rect(300, 350, pygame.Color('#243240'), 255, 10, 130, 185, screen)
        draw_rect(300, 350, pygame.Color('#243240'), 255, 10, 490, 185, screen)
        draw_rect(300, 350, pygame.Color('#243240'), 255, 10, 850, 185, screen)

        # text
        draw_text(50, 'EASY', None, 205, 335, pygame.Color('#FFFF33'), None, screen)
        draw_text(15, None, None, 190, 400, pygame.Color('white'), 'ONE SENTENCE FOR ROUND', screen)

        draw_text(50, 'NORMAL', None, 520, 335, pygame.Color('#FFFF33'), None, screen)
        draw_text(15, None, None, 550, 400, pygame.Color('white'), 'TWO SENTENCE FOR ROUND', screen)

        draw_text(50, 'HARD', None, 925, 335, pygame.Color('#FFFF33'), None, screen)
        draw_text(15, None, None, 910, 400, pygame.Color('white'), 'THREE SENTENCE FOR ROUND', screen)

        clock.tick(60)
        pygame.display.update()
