
import pygame
from TypeZone.lesson.images import *
from TypeZone.functions import close

blue_gray = (51, 63, 80)
black = (0, 0, 0)
white = (255, 255, 255)
screen = pygame.display.set_mode((1280, 720))

class Lesson1(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)

    def addText(self):
        self.screen.blit(kbt, (230, 425))
        self.screen.blit(self.mainFont.render('Learning The Home Row', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This lesson will focus on using the ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('Home Row keys.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('on to typing full words and some short text.', True, blue_gray), (225, 275))
        self.screen.blit(self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 325))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 350))






class Lesson2(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)


    def addText(self):
        self.screen.blit(kbh, (230, 425))
        self.screen.blit(self.mainFont.render('Learning The Top Row', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This lesson will focus on using the ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('Top Row keys.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray),
                         (225, 250))
        self.screen.blit(self.font.render('on to typing full words and some short text.', True, blue_gray),
                         (225, 275))
        self.screen.blit(
            self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 325))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 350))

class Lesson3(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)


    def addText(self):
        self.screen.blit(kbb, (230, 425))
        self.screen.blit(self.mainFont.render('Learning The Bottom Row', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This lesson will focus on using the ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('Bottom Row keys.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('on to typing full words and some short text.', True, blue_gray), (225, 275))
        self.screen.blit(self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 325))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 350))


class Lesson4(object):
    def __init__(self):
        pygame.init()

        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)


    def addText(self):
        self.screen.blit(kbn, (230, 400))
        self.screen.blit(self.mainFont.render('Learning The Number Row', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This lesson will focus on using numbers. ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray), (225, 225))
        self.screen.blit(self.font.render('on to typing code numbers like security keys.', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 300))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 325))


class Lesson5(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 48)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)


    def addText(self):
        self.screen.blit(kbs, (230, 400))
        self.screen.blit(self.mainFont.render('Learning The Capitalization and Punctuations', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This lesson will focus on using Shift key with alphanumeric keys. ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('You will begin by typing key sequences and then move', True, blue_gray), (225, 225))
        self.screen.blit(self.font.render('on to typing full words and some short text.', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('As you complete this exercise, you will get better at ', True, blue_gray), (225, 300))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 325))

class Review(object):
    def __init__(self):
        pygame.init()
        self.mainFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 50)
        self.optFont = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 30)
        self.font = pygame.font.Font('TypeZone/lesson/Ebisu-Light.ttf', 24)
        self.screen = pygame.display.set_mode((1280, 720))
        self.screen.fill(white)


    def addText(self):
        self.screen.blit(full, (230, 380))
        self.screen.blit(self.mainFont.render('Review of Everything You Have Practiced', True, blue_gray), (225, 80))
        self.screen.blit(self.font.render('This part of the module is just a review of ', True, blue_gray), (225, 175))
        self.screen.blit(self.font.render('everything in this lesson module.', True, blue_gray), (225, 200))
        self.screen.blit(self.font.render('Hopefully, after you finished this last activity,', True, blue_gray), (225, 250))
        self.screen.blit(self.font.render('you will get better at ', True, blue_gray), (225, 275))
        self.screen.blit(self.font.render('typing without looking at your keyboard.', True, blue_gray), (225, 300))
