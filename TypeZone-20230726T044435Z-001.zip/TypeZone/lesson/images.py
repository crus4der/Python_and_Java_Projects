import pygame,os


but_width, but_height = 260, 180  # lesson button
bac_width, bac_height = 25, 25  # back button
inf_width, inf_height = 300, 300  # information img
kb_width, kb_height = 630, 230  # white keyboard
kbh_width, kbh_height = 630, 230  # home keys
kbt_width, kbt_height = 630, 230  # top keys
kbb_width, kbb_height = 630, 230  # bottom keys
kbn_width, kbn_height = 630, 230  # number keys
kbs_width, kbs_height = 630, 230  # shift keys
lefth_width, lefth_height = 630, 230  # left hand home
next_width, next_height = 25, 25  # next button
full_width, full_height = 630, 230  # colored keyboard
ff_width, ff_height = 25, 25  # skip button

# images
lesson1Img = pygame.image.load('TypeZone/lesson/MImages/lesson1.png')
lesson2Img = pygame.image.load('TypeZone/lesson/MImages/lesson2.png')
lesson3Img = pygame.image.load('TypeZone/lesson/MImages/lesson3.png')
lesson4Img = pygame.image.load('TypeZone/lesson/MImages/lesson4.png')
lesson5Img = pygame.image.load('TypeZone/lesson/MImages/lesson3.png')
reviewImg = pygame.image.load('TypeZone/lesson/MImages/review.png')
backImg = pygame.image.load('TypeZone/lesson/MImages/back-arrow.png')
infImg = pygame.image.load('TypeZone/lesson/MImages/information.png')
kbImg = pygame.image.load('TypeZone/lesson/MImages/keyboard.jpg')
kbhImg = pygame.image.load('TypeZone/lesson/MImages/home row.jpg')
kbtImg = pygame.image.load('TypeZone/lesson/MImages/top.jpg')
kbbImg = pygame.image.load('TypeZone/lesson/MImages/bot.jpg')
kbnImg = pygame.image.load('TypeZone/lesson/MImages/num.jpg')
kbsImg = pygame.image.load('TypeZone/lesson/MImages/shift.jpg')
lefthImg = pygame.image.load('TypeZone/lesson/MImages/lefth.jpg')
nextImg = pygame.image.load('TypeZone/lesson/MImages/right-arrow.png')
fullImg = pygame.image.load('TypeZone/lesson/MImages/full.jpg')
ffImg = pygame.image.load('TypeZone/lesson/MImages/fast-forward-arrows.png')

lesson1 = pygame.transform.scale(lesson1Img, (but_width, but_height))
lesson2 = pygame.transform.scale(lesson2Img, (but_width, but_height))
lesson3 = pygame.transform.scale(lesson3Img, (but_width, but_height))
lesson4 = pygame.transform.scale(lesson4Img, (but_width, but_height))
lesson5 = pygame.transform.scale(lesson5Img, (but_width, but_height))
review = pygame.transform.scale(reviewImg, (but_width, but_height))
back = pygame.transform.scale(backImg, (bac_width, bac_height))
inf = pygame.transform.scale(infImg, (inf_width, inf_height))
kb = pygame.transform.scale(kbImg, (kb_width, kb_height))
kbh = pygame.transform.scale(kbhImg, (kbh_width, kbh_height))
kbt = pygame.transform.scale(kbtImg, (kbt_width, kbt_height))
kbb = pygame.transform.scale(kbbImg, (kbb_width, kbb_height))
kbn = pygame.transform.scale(kbnImg, (kbn_width, kbn_height))
kbs = pygame.transform.scale(kbsImg, (kbs_width, kbs_height))
lefth = pygame.transform.scale(lefthImg, (lefth_width, lefth_height))
next = pygame.transform.scale(nextImg, (next_width, next_height))
full = pygame.transform.scale(fullImg, (full_width, full_height))
ff = pygame.transform.scale(ffImg, (ff_width, ff_height))