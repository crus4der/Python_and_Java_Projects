import pygame, os,sys
from CPE8.TypeZone.functions import draw_rect, Button, draw_text



pygame.init()
screen = pygame.display.set_mode((1280, 720))

font = pygame.font.Font('lesson/Ebisu-Light.ttf', 42)
font_text = pygame.font.Font('lesson/Ebisu-Light.ttf', 30)

def time(time_text):

    time_graph = pygame.image.load('..//graph/time.png')
    screen.blit(time_graph, (550 + 240, 150+ 120))
    show_time = font.render(str(time_text) + 's', True, pygame.Color('#243240'))
    time_width, time_height = show_time.get_size()
    screen.blit(show_time, (790 + 100 - (time_width/2), 270 + 100 - (time_height/2)))
    str_time = font_text.render('time', True, pygame.Color('#243240'))
    str_width, str_height = str_time.get_size()
    screen.blit(str_time, (790 + 100 - (str_width/2), 270 + 210 ))


def wpm(wpm_text):

    wpm_graph = pygame.image.load('..//graph/wpm0.png')
    if 0 < wpm_text <= 10:
        wpm_graph = pygame.image.load('..//graph/wpm10.png')
    elif 10 < wpm_text <= 20:
        wpm_graph = pygame.image.load('..//graph/wpm20.png')
    elif 20 < wpm_text <= 30:
        wpm_graph = pygame.image.load('..//graph/wpm30.png')
    elif 30 < wpm_text <= 40:
        wpm_graph = pygame.image.load('..//graph/wpm40.png')
    elif 40 < wpm_text <= 50:
        wpm_graph = pygame.image.load('..//graph/wpm50.png')
    elif 50 < wpm_text <= 60:
        wpm_graph = pygame.image.load('..//graph/wpm60.png')
    elif 60 < wpm_text <= 70:
        wpm_graph = pygame.image.load('..//graph/wpm70.png')
    elif 70 < wpm_text <= 80:
        wpm_graph = pygame.image.load('..//graph/wpm80.png')
    elif 80 < wpm_text <= 90:
        wpm_graph = pygame.image.load('..//graph/wpm90.png')
    elif wpm_text > 90:
        wpm_graph = pygame.image.load('..//graph/wpm100.png')
    else:
        wpm_graph = wpm_graph

    screen.blit(wpm_graph, (300 + 240, 150 + 120))
    show_wpm = font.render(str(wpm_text), True, pygame.Color('#243240'))
    wpm_width, wpm_height = show_wpm.get_size()
    screen.blit(show_wpm, (540 + 100 - (wpm_width / 2), 270 + 100 - (wpm_height / 2)))
    str_wpm = font_text.render('wpm', True, pygame.Color('#243240'))
    str_width, str_height = str_wpm.get_size()
    screen.blit(str_wpm, (540 + 100 - (str_width / 2), 270 + 210))


def accuracy(accuracy_text):

    accuracy_graph = pygame.image.load('..//graph/acc0.png')
    if 0 < accuracy_text <= 10:
        accuracy_graph = pygame.image.load('..//graph/acc10.png')
    elif 10 < accuracy_text <= 20:
        accuracy_graph = pygame.image.load('..//graph/acc20.png')
    elif 20 < accuracy_text <= 30:
        accuracy_graph = pygame.image.load('..//graph/acc30.png')
    elif 30 < accuracy_text <= 40:
        accuracy_graph = pygame.image.load('..//graph/acc40.png')
    elif 40 < accuracy_text <= 50:
        accuracy_graph = pygame.image.load('..//graph/acc50.png')
    elif 50 < accuracy_text <= 60:
        accuracy_graph = pygame.image.load('..//graph/acc60.png')
    elif 60 < accuracy_text <= 70:
        accuracy_graph = pygame.image.load('..//graph/acc70.png')
    elif 70 < accuracy_text <= 80:
        accuracy_graph = pygame.image.load('..//graph/acc80.png')
    elif 80 < accuracy_text <= 90:
        accuracy_graph = pygame.image.load('..//graph/acc90.png')
    elif 90 < accuracy_text > 90:
        accuracy_graph = pygame.image.load('..//graph/acc100.png')
    else:
        accuracy_graph = accuracy_graph

    screen.blit(accuracy_graph, (50 + 240, 150 + 120))
    show_accuracy = font.render(str(accuracy_text) + '%', True, pygame.Color('#243240'))
    accuracy_width, accuracy_height = show_accuracy.get_size()
    screen.blit(show_accuracy, (290 + 100 - (accuracy_width / 2), 270 + 100 - (accuracy_height / 2)))
    str_accuracy = font_text.render('accuracy', True, pygame.Color('#243240'))
    str_width, str_height = str_accuracy.get_size()
    screen.blit(str_accuracy, (290 + 100 - (str_width / 2), 270 + 210))






def result(tim, wp, accurac):

    cont = Button((255,255,255), 790, 560, 230, 62)
    color = pygame.Color('white')
    active_color = pygame.Color('#FFFF33')

    loop = True
    while loop:
        draw_rect(800, 500, pygame.Color('#92b6db'), 255, 20, 240, 120, screen)
        time(tim)
        wpm(wp)
        accuracy(accurac)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 550 + 240 , 425 + 120, screen)
        draw_text(30, 'CONTINUE', None, 585 + 240, 443 + 120, color, None, screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                screen.fill((255,255,255))
                loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pygame.mouse.get_pos()):
                    color = active_color
                else:
                    color = pygame.Color('white')


        pygame.display.update()