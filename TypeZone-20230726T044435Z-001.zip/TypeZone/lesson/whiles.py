import sys
from CPE8.TypeZone.lesson.lessons import *
from CPE8.TypeZone.functions import draw_rect, Button
from CPE8.TypeZone.lesson.rect import draw_text
from CPE8.TypeZone.lesson.tester import pre_test
font_v = pygame.font.Font('TypeZone/lesson/Valorant Font.ttf', 13)
font_z = pygame.font.Font('TypeZone/lesson/Valorant Font.ttf', 30)
cont = Button((255,255,255), 970, 600, 230, 62)
click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')

def L1():
    color = pygame.Color('white')
    bck = Button(color,30, 30, 65, 40)
    loop = True
    txt = "aa ss dd ff jj kk ll ;; as df as df jk l; jk l; asdf jkl; asdf jkl; aa dd jj kk ss ff kk ;; " \
          "adjl adjl sfk; sfk; as df jk l; ad jl sf k; as as all all ask ask sad sad sals sals " \
          #"dad dad fall fall flask flask lads lads alas alas lada lada flak flak " \
          #"jaffa jaffa jaffa salad salad "

    while loop:
        Lesson1().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, (255,255,255), screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False
                elif cont.isOver(pos):
                    click.play()
                    pre_test(txt, 120)
                    loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')


def L2():
    color = pygame.Color('white')
    bck = Button(color, 30, 30, 65, 40)
    txt = "qq ww ee rr uu ii oo pp qe uo qe uo wr ip wr ip qw er ui op qu wi eo rp qwer uiop " \
          "qq ee uu oo ww rr ii pp qeuo wrip qeuo wrip equip equip equity equity erupt erupt " \
          #"power power quote quote query query tower tower wiper wiper typewriter typewriter"


    loop = True
    while loop:
        Lesson2().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, color, screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False

                elif cont.isOver(pos):
                    click.play()
                    pre_test(txt, 135)
                    loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

def L3():
    color = pygame.Color('white')
    bck = Button(color, 30, 30, 65, 40)
    txt = "zz xx cc vv mm ,, .. // zc xv m. ,/ z, x. c/ vm zxcv m,./ m, cv xz /. " \
          "zcm. xv,/ zxc vm, ./ zxc vm, ./ vm c, x. z/ zebra zebra zabba zabba zipper zipper "

    loop = True
    while loop:
        Lesson3().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, color, screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False

                elif cont.isOver(pos):
                   click.play()
                   pre_test(txt, 135)
                   loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

def L4():
    color = pygame.Color('white')
    bck = Button(color, 30, 30, 65, 40)
    txt = "11 22 33 44 55 66 77 88 99 00 13 47 80 " \
          "607-94-2490 555-90-0311 557-73-5550 615-82-6451 "\
           "24 79 1234 7890 1728 3940 1470 2389 556-25-2336 559- 25-5486"

    loop = True
    while loop:
        Lesson4().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, color, screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False

                elif cont.isOver(pos):
                    click.play()
                    pre_test(txt, 135)
                    loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

def L5():
    color = pygame.Color('white')
    bck = Button(color, 30, 30, 65, 40)
    txt = "Jjjj Jjjj Jjjj Ffff Ffff Ffff jJj jJj jJj fFf fFf kK dD lL sS aA Kk Dd Ll Ss Aa " \
          "uU rR iI eE oO wW pP qQ Uu Rr Ii Ee Oo Ww Pp Qq " \
          "mM vV nN cC bb xX zZ Mm Vv Nn Cc Bb Xx Zz "

    loop = True
    while loop:
        Lesson5().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, color, screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False

                elif cont.isOver(pos):
                    click.play()
                    pre_test(txt, 135)
                    loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')

def rev():
    color = pygame.Color('white')
    bck = Button(color, 30, 30, 65, 40)
    txt = "Advanced typists type with a speed of 120 words per minute and even above that. 216 words in one " \
          "minute was the highest ever typing speed reached by Stella Pajunas in 1946. According to the Guiness Book " \

    loop = True
    while loop:
        Review().addText()
        draw_rect(65, 40, pygame.Color('#243240'), 255, 12, 30, 30, screen)
        draw_text(font_v, 'BACK', None, 45 , 45, color, screen, 0)
        draw_rect(230, 62, pygame.Color('#243240'), 255, 12, 970, 600, screen)
        draw_text(font_z, 'CONTINUE', None, 1007, 618, color, screen, 0)
        pygame.display.update()

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bck.isOver(pos):
                    click.play()
                    screen.fill((255,255,255))
                    pygame.display.update()
                    loop = False

                elif cont.isOver(pos):
                    click.play()
                    pre_test(txt, 115)
                    loop = False

            elif event.type == pygame.MOUSEMOTION:
                if cont.isOver(pos):
                    color = pygame.Color('#FFFF33')
                else:
                    color = pygame.Color('white')


