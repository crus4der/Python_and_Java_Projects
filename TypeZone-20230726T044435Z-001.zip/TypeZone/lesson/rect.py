import pygame
from CPE8.TypeZone.functions import draw_rect

screen = pygame.display.set_mode((1280, 720))
pygame.init()
blue_gray = (51, 63, 80)
black = (0, 0, 0)
white = (255, 255, 255)
yellow = pygame.Color('#FFFF33')

font_v = pygame.font.Font('TypeZone/lesson/Valorant Font.ttf', 28)
font_z = pygame.font.SysFont('Calibri', 28 , True)
def draw_text(font, text, text_2,offset_x, offset_y, color, scr, add):
    # homage button
    text_surf = font.render(text, True, color)
    text_surf2 = font.render(text_2, True, color)
    # ---------
    get_height = text_surf.get_height()

    # displays
    scr.blit(text_surf, (offset_x, offset_y))
    screen.blit(text_surf2, (offset_x + 35 + add, offset_y + get_height + 5))

def rectan():
    home_icon = pygame.image.load('TypeZone/Images/home.png')
    home_icon = pygame.transform.scale(home_icon, (48, 48))
    screen.blit(home_icon, (40, 40))
    draw_rect(266, 183, blue_gray, 255, 15, 125, 120, screen)
    draw_rect(175, 1, white, 255, 0, 170, 180, screen)
    draw_rect(266, 183, blue_gray, 255, 15, 510, 120, screen)
    draw_rect(175, 1, white, 255, 0, 555, 180, screen)
    draw_rect(266, 183, blue_gray, 255, 15, 895, 120, screen)
    draw_rect(175, 1, white, 255, 0, 940, 180, screen)
    draw_rect(266, 183, blue_gray, 255, 15, 125, 420, screen)
    draw_rect(175, 1, white, 255, 0, 170, 480, screen)
    draw_rect(266, 183, blue_gray, 255, 15, 510, 420, screen)
    draw_rect(175, 1, white, 255, 0, 555, 480, screen)
    draw_rect(266, 183, blue_gray, 255, 15, 895, 420, screen)
    draw_rect(175, 1, white, 255, 0, 940, 480, screen)

    # draw text
    draw_text(font_v, 'Lesson 1', None, 195, 145, yellow, screen, 0)
    draw_text(font_v, 'Lesson 2', None, 580, 145, yellow, screen, 0)
    draw_text(font_v, 'Lesson 3', None, 963, 145, yellow, screen, 0)
    draw_text(font_v, 'Lesson 4', None, 192, 445, yellow, screen, 0)
    draw_text(font_v, 'Lesson 5', None, 577, 445, yellow, screen, 0)
    draw_text(font_v, 'review', None, 972, 445, yellow, screen, 0)

    # draw text 2
    draw_text(font_z, 'HOME ROW', 'KEYS', 189, 203, white, screen, 5)
    draw_text(font_z, 'TOP ROW', 'KEYS', 584, 203, white, screen, 0)
    draw_text(font_z, 'BOTTOM ROW', 'KEYS', 945, 203, white, screen, 23)
    draw_text(font_z, 'NUMBER', None, 198, 508, white, screen, 0)
    draw_text(font_z, 'CAPITAL LETTERS', '& PUNCTUATION', 545, 503, white, screen, - 35)
    draw_text(font_z, 'REVIEW WORK', None, 940, 503, white, screen, 0)

    pygame.display.update()