import pygame, os
from TypeZone.debug.Test import testing
from TypeZone.result import result

font = pygame.font.Font('TypeZone/lesson/monof55.ttf', 33)

def acc(cor_ans, test):
    x = 0
    for i in range(len(test)):
        try:
            if cor_ans[i] == test[i]:
                x += 1
            else:
                x = x
        except IndexError:
            break
    return round((x / len(test)) * 100)

def pre_test(test, y):
    testing(test, font, 150, y)
    try:
        wpm = ((len(testing.show) * 60) / (5 * testing.time))
    except ZeroDivisionError:
        wpm = 0
    pygame.time.delay(500)
    result(testing.time, round(wpm), acc(testing.show, test))

