import pygame, sys
import pygame as pg

class Button:
    def __init__(self, color, x, y, width, height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def isOver(self, pos):
        # Pos is the mouse position or a tuple of (x,y) coordinates
        if self.x < pos[0] < self.x + self.width:
            if self.y < pos[1] < self.y + self.height:
                return True

    def draw_rect(self, alpha, screen, roundness):
        surf_rect = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        surf_rect.set_alpha(alpha)
        pygame.draw.rect(screen, self.color,pygame.Rect(self.x, self.y, self.width, self.height), border_radius = roundness)

        #pygame.draw.rect(win, color, pygame.Rect(400, 235, 475, 85), 3, 12)
def close():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


class Rect(pg.sprite.Sprite):

    def __init__(self, width, height, color,alpha):
        self.width = width
        self.height = height
        self.color = color
        self.alpha = alpha

        pg.sprite.Sprite.__init__(self)
        self.original_image = pg.Surface((self.width, self.height))
        self.original_image.fill((255, 255, 255))
        self.image = self.original_image
        self.rect = self.image.get_rect()


    def set_rounded(self, roundness):
        size = self.original_image.get_size()
        self.rect_image = pg.Surface(size, pg.SRCALPHA)
        pg.draw.rect(self.rect_image, self.color, (0, 0, *size), border_radius=roundness)

        self.image = self.original_image.copy().convert_alpha()
        self.image.set_alpha(self.alpha)
        self.image.blit(self.rect_image, (0, 0), None, pg.BLEND_RGBA_MIN)



class Rectangle(pg.sprite.Sprite):
    pygame.init()
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.original_image = pg.Surface((475, 85))
        self.original_image.fill((255, 255, 255))
        self.image = self.original_image
        self.rect = self.image.get_rect()


    def set_rounded(self, roundness):
        size = self.original_image.get_size()
        self.rect_image = pg.Surface(size, pg.SRCALPHA)
        pg.draw.rect(self.rect_image, (255, 255, 255), (0, 0, *size), border_radius=roundness)

        self.image = self.original_image.copy().convert_alpha()
        self.image.blit(self.rect_image, (0, 0), None, pg.BLEND_RGBA_MIN)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.attack_animation = False
        self.sprites = []
        self.sprites.append(pygame.image.load('TypeZone/Images/play.png'))
        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        self.rect.topleft = [pos_x, pos_y]


    def attack(self):
        self.attack_animation = True


    def stop(self):
        self.sprites.pop()


    #def draw_text(self, screen, message, y_val, f_size, color):
    #    font = pygame.font.Font(None, f_size)
    #    text = font.render(message, True, color)
    #    text_rect = text.get_rect(center=(self.w / 2, y_val))
    #    screen.blit(text, text_rect)
    #    pygame.display.update()


def blit_text(surface, text, pos, font, color):
    words = [word.split(' ') for word in text.splitlines()] # 2D array where each row is a list of words.
    space = font.size(' ')[0]  # The width of a space.
    x, y = pos
    width, height = surface.get_size()
    max_width = width - x
    wid, hei = 0, 0
    for line in words:
        for word in line:
            word_surface = font.render(word, True, color)
            word_width, word_height = word_surface.get_size()
            hei = word_height
            if x + word_width >= max_width:
                x = pos[0]  # Reset the x.
                y += word_height + 10  # Start on new row.
            for let in word:
                let_surface = font.render(let, True, color)
                let_width, let_height = let_surface.get_size()
                wid = let_width
                surface.blit(let_surface, (x, y))
                x += let_width + space
            x += wid + space
        #x = pos[0]  # Reset the x.
        #y += hei  # Start on new row.

def rect(screen, pos, color, width, height, alpha):
    surf_rect = pygame.Surface((width, height), pygame.SRCALPHA)
    surf_rect.set_alpha(alpha)
    surf_rect.fill(color)


    screen.blit(surf_rect, pos)
    pygame.display.update()

def draw_rect(width, height, color, alpha, roundness, x, y, screen):
    rect_object = Rect(width, height, color, alpha)
    rect_object.set_rounded(roundness)
    rect_object.rect = (x, y)
    drw_rect = pygame.sprite.Group(rect_object)
    drw_rect.draw(screen)


# text
def draw_text(size, text, text_2,offset_x, offset_y, color, user, screen, bold = False ):
    # homage button
    font = pygame.font.Font('TypeZone/font/Valorant Font.ttf', size)
    text_surf = font.render(text, True, color)
    text_surf2 = font.render(text_2, True, color)

    # user text
    font = pygame.font.SysFont('Calibri', size, bold)
    name_surface = font.render(user, True, color)

    # ---------
    get_height = text_surf.get_height()

    # displays
    screen.blit(name_surface, (offset_x, offset_y))
    screen.blit(text_surf, (offset_x, offset_y))
    screen.blit(text_surf2, (offset_x, offset_y + get_height - get_height/(get_height/1.5)))