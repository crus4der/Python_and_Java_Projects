import pygame, os, sys
from CPE8.TypeZone.functions import Button, draw_rect, close
from CPE8.TypeZone.lesson.rect import rectan
from CPE8.TypeZone.lesson.whiles import L1, L2, L3, L4, L5, rev



screen = pygame.display.set_mode((1280, 720))
pygame.init()


blue_gray = (51, 63, 80)
black = (0, 0, 0)
white = (255, 255, 255)
yellow = pygame.Color('#FFFF33')



# button {
l1 = Button(white, 125, 120, 266, 183)
l2 = Button(white, 510, 120, 266, 183)
l3 = Button(white, 895, 120, 266, 183)
l4 = Button(white, 125, 420, 266, 183)
l5 = Button(white, 510, 420, 266, 183)
l6 = Button(white, 895, 420, 266, 183)
home = Button((255, 255, 255), 40, 40, 48, 48)
click = pygame.mixer.Sound('TypeZone/sounds/Mouseclick.mp3')

def main_page():
    loop = True
    while loop:

        for event in pygame.event.get():
            pos = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEMOTION:

                if l1.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 115, 130, screen)

                elif l2.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 500, 130, screen)

                elif l3.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 885, 130, screen)

                elif l4.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 115, 430, screen)

                elif l5.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 500, 430, screen)

                elif l6.isOver(pos):
                    screen.fill(white)
                    draw_rect(266, 183, yellow, 255, 15, 885, 430, screen)

                else:
                    screen.fill(white)

            rectan()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if l1.isOver(pos):
                    click.play()
                    L1()
                elif l2.isOver(pos):
                    click.play()
                    L2()
                elif l3.isOver(pos):
                    click.play()
                    L3()
                elif l4.isOver(pos):
                    click.play()
                    L4()
                elif l5.isOver(pos):
                    click.play()
                    L5()
                elif l6.isOver(pos):
                    click.play()
                    rev()
                elif home.isOver(pos):
                    loop = False



